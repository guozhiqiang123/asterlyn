// src/android-profile.ts
var ANDROID_PROFILE = Object.freeze({
  "id": "android-jvm",
  "program": {
    "entry": "server-programs/android-server.mjs",
    "tools": [
      {
        "id": "serverJava",
        "kind": "java",
        "minimumMajor": 25,
        "maximumMajorExclusive": 26
      },
      {
        "id": "kotlinJava",
        "kind": "java",
        "minimumMajor": 17,
        "maximumMajorExclusive": 25
      }
    ],
    "components": [
      {
        "id": "jdtls",
        "version": "1.62.0",
        "archiveDigest": "sha256:f587dafd8410633c2c2bf005e853a2bbb03cddee88933d49bfe6d9cb1cf09342",
        "contentDigest": "sha256:ca0c9c9f4797c8273bc39f8d786f63fa87a6ef2b4ac4d4577fc49646761e4126"
      },
      {
        "id": "kotlin-language-server",
        "version": "1.3.13",
        "archiveDigest": "sha256:4fe7d71d087b307c7869036171bd9d8c6a4284cd7c25b89098b0a24eb2d9b6d2",
        "contentDigest": "sha256:511aee8b85ef906747190bbe39ec10a94975b5d5b41b82b499a8558162e4d941"
      },
      {
        "id": "kotlin-compiler-bridge",
        "version": "2.2.0",
        "archiveDigest": "sha256:58a12d60fcd67503d0617d18b4d45f882c3d078f4e132053b66acd0d91f77077",
        "contentDigest": "sha256:ea42e99bb94b232f5d08f1753349c31ac4df1d88cdbf5e58f11a2e4b61285ba7"
      }
    ]
  },
  "selectors": [
    {
      "languageId": "java",
      "extensions": [
        ".java"
      ]
    },
    {
      "languageId": "kotlin",
      "extensions": [
        ".kt"
      ]
    }
  ],
  "model": {
    "pluginId": "dev.asterlyn.android-gradle",
    "serviceId": "android-gradle-model",
    "schema": 1
  }
});
function isAndroidWorkspace(context) {
  return context.evidence.some((evidence) => {
    if (evidence.kind !== "workspace-catalog" || evidence.values.truncated !== false || !Array.isArray(evidence.values.files)) return false;
    const windows = evidence.values.platform === "windows";
    if (!windows && evidence.values.platform !== "posix") return false;
    const files = evidence.values.files.map((value) => typeof value === "string" ? value : value && typeof value === "object" && "workspacePath" in value && typeof value.workspacePath === "string" ? value.workspacePath : "").filter(Boolean).map((path) => windows ? path.replaceAll("\\", "/").toLowerCase() : path);
    const wrapper = files.includes(windows ? "gradlew.bat" : "gradlew");
    const gradle = files.some((path) => ["build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts", "gradle/wrapper/gradle-wrapper.properties"].includes(path));
    return wrapper && gradle && files.some((path) => windows ? path === "src/main/androidmanifest.xml" || path.endsWith("/src/main/androidmanifest.xml") : path === "src/main/AndroidManifest.xml" || path.endsWith("/src/main/AndroidManifest.xml"));
  });
}

// src/plugin.ts
var LSP_PLUGIN_ID = "dev.asterlyn.lsp";
var RUST_LANGUAGE_SERVICE_ID = "rust";
var TYPESCRIPT_LANGUAGE_SERVICE_ID = "typescript-javascript";
var languageService = Object.freeze({
  kind: "language-service",
  id: TYPESCRIPT_LANGUAGE_SERVICE_ID,
  label: "TypeScript / JavaScript",
  serverId: "typescript",
  languageIds: Object.freeze(["typescript", "typescriptreact", "javascript", "javascriptreact"]),
  extensions: Object.freeze([".ts", ".tsx", ".js", ".jsx", ".mts", ".cts", ".mjs", ".cjs"]),
  rootMarkers: Object.freeze(["tsconfig.json", "jsconfig.json", "package.json"])
});
var rustService = Object.freeze({
  kind: "language-service",
  id: RUST_LANGUAGE_SERVICE_ID,
  label: "Rust",
  serverId: "rust-analyzer",
  languageIds: Object.freeze(["rust"]),
  extensions: Object.freeze([".rs"]),
  rootMarkers: Object.freeze(["Cargo.toml"])
});
var LSP_PLUGIN_MANIFEST = Object.freeze({
  schemaVersion: 3,
  sdkMajor: 1,
  id: LSP_PLUGIN_ID,
  version: "0.3.0",
  nameKey: "name",
  descriptionKey: "description",
  localization: Object.freeze({
    defaultLocale: "en-US",
    locales: Object.freeze({
      "en-US": Object.freeze({
        name: "Language services",
        description: "TypeScript, JavaScript, Rust and Android Java/Kotlin language services."
      }),
      "zh-CN": Object.freeze({
        name: "\u8BED\u8A00\u670D\u52A1",
        description: "TypeScript\u3001JavaScript\u3001Rust \u548C Android Java/Kotlin \u8BED\u8A00\u670D\u52A1\u3002"
      })
    })
  }),
  settings: Object.freeze([]),
  capabilities: Object.freeze(["languageServices", "pluginDependencies", "packagedLanguageServices"]),
  dependencies: Object.freeze([Object.freeze({ id: "dev.asterlyn.android-gradle", minimum: "0.6.0", maximumExclusive: "1.0.0" })]),
  permissions: Object.freeze(["host.language-services.execute"]),
  languageServers: Object.freeze([ANDROID_PROFILE]),
  distribution: Object.freeze({
    repository: "guozhiqiang123/asterlyn-plugin-lsp",
    runtime: Object.freeze({ protocol: 1, entry: "runtime/plugin.js" }),
    hostCompatibility: Object.freeze({ minimum: "0.1.22", maximumExclusive: "0.2.0" }),
    license: Object.freeze({ expression: "MIT", file: "LICENSE" }),
    integrity: Object.freeze({})
  })
});
function matchesLanguageWorkspace(_context) {
  return true;
}
var LSP_PLUGIN = Object.freeze({
  sdkMajor: 1,
  id: LSP_PLUGIN_ID,
  version: LSP_PLUGIN_MANIFEST.version,
  manifest: LSP_PLUGIN_MANIFEST,
  matches: matchesLanguageWorkspace,
  activate: (context) => {
    const { contribute } = context;
    const contributions = [contribute(languageService), contribute(rustService)];
    if (isAndroidWorkspace(context)) contributions.push(contribute({ kind: "language-service", id: "android-jvm", label: "Android Java / Kotlin", serverId: ANDROID_PROFILE.id, languageIds: ["java", "kotlin"], extensions: [".java", ".kt"], rootMarkers: ["settings.gradle", "settings.gradle.kts", "build.gradle", "build.gradle.kts"] }));
    return Object.freeze({ dispose: () => contributions.forEach((item) => item.dispose()) });
  }
});
export {
  LSP_PLUGIN,
  LSP_PLUGIN_ID,
  LSP_PLUGIN_MANIFEST,
  RUST_LANGUAGE_SERVICE_ID,
  TYPESCRIPT_LANGUAGE_SERVICE_ID,
  matchesLanguageWorkspace
};
