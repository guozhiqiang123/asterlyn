var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/deployment-recovery.ts
var deployment_recovery_exports = {};
__export(deployment_recovery_exports, {
  buildUpdateIncompatibleRecovery: () => buildUpdateIncompatibleRecovery,
  isUpdateIncompatibleDeployment: () => isUpdateIncompatibleDeployment
});
function buildUpdateIncompatibleRecovery(deployment, targetId, applicationId) {
  if (!isUpdateIncompatibleDeployment(deployment)) return null;
  return {
    confirmation: {
      titleKey: "run.recovery.uninstall.title",
      messageKey: "run.recovery.uninstall.message",
      confirmLabelKey: "run.recovery.uninstall.confirm",
      cancelLabelKey: "run.recovery.uninstall.cancel",
      destructive: true
    },
    operation: {
      operationId: "android.adb.uninstall",
      parameters: { target: targetId, application: applicationId }
    }
  };
}
function isUpdateIncompatibleDeployment(result) {
  if (result.status === "succeeded" || result.truncated) return false;
  return /(?:^|[^A-Za-z0-9_])INSTALL_FAILED_UPDATE_INCOMPATIBLE(?:$|[^A-Za-z0-9_])/u.test(`${result.stdout}
${result.stderr}`);
}
var init_deployment_recovery = __esm({
  "src/deployment-recovery.ts"() {
    "use strict";
  }
});

// src/detector.ts
var ANDROID_GRADLE_DETECTOR_LIMITS = Object.freeze({
  // Matches the host-owned project catalog ceiling; the detector never expands it.
  maxPaths: 1e5,
  maxPathLength: 4096
});
var SETTINGS = /* @__PURE__ */ new Set(["settings.gradle", "settings.gradle.kts"]);
var BUILDS = /* @__PURE__ */ new Set(["build.gradle", "build.gradle.kts"]);
var WRAPPERS = /* @__PURE__ */ new Set(["gradlew", "gradlew.bat"]);
function detectAndroidGradleEvidence(input) {
  const platform = input.platform ?? "posix";
  if (input.files.length > ANDROID_GRADLE_DETECTOR_LIMITS.maxPaths) {
    return emptySnapshot(input.workspaceRoot, input.generation, platform, false, input.catalogTruncated === true);
  }
  const paths = input.files.map((file) => normalizeWorkspacePath(file.workspacePath, platform)).filter((path) => path !== null);
  const unique = [...new Set(paths)].sort(comparePaths);
  const rootNames = new Set(unique.filter((path) => !path.includes("/")));
  const expectedWrapper = platform === "windows" ? "gradlew.bat" : "gradlew";
  const wrapper = rootNames.has(expectedWrapper) ? expectedWrapper : null;
  const rootSettings = [...rootNames].some((name) => SETTINGS.has(name));
  const rootBuild = [...rootNames].some((name) => BUILDS.has(name));
  const wrapperProperties = unique.includes("gradle/wrapper/gradle-wrapper.properties");
  const gradle = rootSettings || rootBuild || wrapper !== null || wrapperProperties;
  const androidManifest = unique.some((path) => isAndroidManifest(path, platform));
  const android = gradle && androidManifest;
  return Object.freeze({
    kind: "android-gradle-evidence",
    workspaceRoot: input.workspaceRoot,
    generation: input.generation,
    platform,
    bounded: true,
    catalogTruncated: input.catalogTruncated === true,
    gradle,
    android,
    wrapper,
    evidence: Object.freeze(unique.filter((path) => isEvidencePath(path, platform)))
  });
}
function isRunnableGradleWorkspace(evidence) {
  const expectedWrapper = evidence.platform === "windows" ? "gradlew.bat" : "gradlew";
  return evidence.bounded && !evidence.catalogTruncated && evidence.gradle && evidence.wrapper === expectedWrapper;
}
function emptySnapshot(workspaceRoot, generation, platform, bounded, catalogTruncated) {
  return Object.freeze({
    kind: "android-gradle-evidence",
    workspaceRoot,
    generation,
    platform,
    bounded,
    catalogTruncated,
    gradle: false,
    android: false,
    wrapper: null,
    evidence: Object.freeze([])
  });
}
function normalizeWorkspacePath(value, platform) {
  if (typeof value !== "string" || value.length === 0 || value.length > ANDROID_GRADLE_DETECTOR_LIMITS.maxPathLength || value.includes("\0")) return null;
  const slash = platform === "windows" ? value.replaceAll("\\", "/") : value;
  if (slash.startsWith("/") || /^[A-Za-z]:\//.test(slash) || slash.startsWith("//")) return null;
  const segments = slash.split("/");
  if (segments.some((segment) => segment.length === 0 || segment === "." || segment === "..")) return null;
  const normalized = segments.join("/");
  return platform === "windows" ? normalized.toLowerCase() : normalized;
}
function isAndroidManifest(path, platform) {
  const segments = path.split("/");
  const manifest = platform === "windows" ? segments.at(-1)?.toLowerCase() : segments.at(-1);
  return segments.length >= 3 && segments.at(-3) === "src" && segments.at(-2) === "main" && manifest === (platform === "windows" ? "androidmanifest.xml" : "AndroidManifest.xml");
}
function isEvidencePath(path, platform) {
  return !path.includes("/") && (SETTINGS.has(path) || BUILDS.has(path) || WRAPPERS.has(path)) || path === "gradle/wrapper/gradle-wrapper.properties" || isAndroidManifest(path, platform);
}
function comparePaths(left, right) {
  return left < right ? -1 : left > right ? 1 : 0;
}

// src/discovery.ts
var ANDROID_GRADLE_DISCOVERY_LIMITS = Object.freeze({
  maxOutputBytes: 2 * 1024 * 1024,
  maxLineLength: 16 * 1024,
  maxTasks: 32768
});
var ANDROID_GRADLE_EXECUTION_FLAGS = Object.freeze([
  "--console=plain",
  "--no-daemon",
  "--no-scan"
]);
var ANDROID_GRADLE_TASK_ARGS = Object.freeze([
  "tasks",
  "--all",
  ...ANDROID_GRADLE_EXECUTION_FLAGS
]);
function buildGradleWrapperRequest(evidence) {
  if (!evidence.gradle) return { supported: false, reason: "unsupported-evidence" };
  if (!evidence.bounded || evidence.catalogTruncated) return { supported: false, reason: "unsupported-evidence" };
  const expected = evidence.platform === "windows" ? "gradlew.bat" : "gradlew";
  if (!evidence.wrapper) return { supported: false, reason: "wrapper-missing" };
  if (evidence.wrapper !== expected) return { supported: false, reason: "platform-mismatch" };
  return {
    supported: true,
    request: {
      pluginId: "dev.asterlyn.android-gradle",
      providerId: "gradle-tasks",
      taskId: "discover",
      label: "Gradle tasks",
      executablePath: expected,
      args: [...ANDROID_GRADLE_TASK_ARGS]
    }
  };
}
function parseGradleTasksOutput(output) {
  const bytes = typeof output === "string" ? new TextEncoder().encode(output) : output;
  if (bytes.byteLength > ANDROID_GRADLE_DISCOVERY_LIMITS.maxOutputBytes) return errorSnapshot("Gradle output exceeded the discovery limit.");
  const text = new TextDecoder("utf-8", { fatal: false }).decode(bytes);
  const lines = text.split(/\r?\n/u);
  const records = /* @__PURE__ */ new Map();
  let group = "Other";
  let projectPath = ":";
  let inTaskGroup = false;
  let malformed = false;
  for (let index = 0; index < lines.length; index += 1) {
    const rawLine = lines[index] ?? "";
    const line = stripAnsi(rawLine).trimEnd();
    if (line.length > ANDROID_GRADLE_DISCOVERY_LIMITS.maxLineLength) {
      malformed = true;
      break;
    }
    if (!line.trim()) continue;
    if (/^(?:FAILURE:|BUILD FAILED|Could not determine)/u.test(line.trim())) return errorSnapshot("Gradle task discovery failed.");
    const rootProject = line.match(/Tasks runnable from root project ['"]([^'"]+)['"]/u);
    if (rootProject) {
      projectPath = ":";
      inTaskGroup = false;
      continue;
    }
    const projectHeader = line.match(/Tasks runnable from project ['"]([^'"]+)['"]/u);
    if (projectHeader?.[1]) {
      projectPath = projectHeader[1].startsWith(":") ? projectHeader[1] : `:${projectHeader[1]}`;
      inTaskGroup = false;
      continue;
    }
    const next = stripAnsi(lines[index + 1] ?? "").trim();
    if (/^-{3,}$/u.test(next)) {
      inTaskGroup = /^\s*[A-Za-z][\w -]* tasks\s*$/u.test(line) && !line.includes(":") && !line.includes(" - ");
      if (inTaskGroup) group = line.trim();
      continue;
    }
    if (/^-{3,}$/u.test(line.trim()) || !inTaskGroup) continue;
    const match = line.match(/^\s*((?::[A-Za-z0-9_.-]+)+|[A-Za-z][A-Za-z0-9_.-]*(?::[A-Za-z0-9_.-]+)*)\s*(?:-\s*(.*))?\s*$/u);
    const taskName = match?.[1];
    if (!taskName) continue;
    const id = taskName.startsWith(":") ? taskName : taskName.includes(":") ? `:${taskName}` : `${projectPath === ":" ? ":" : `${projectPath}:`}${taskName}`;
    const projectSegments = id.startsWith(":") ? id.slice(1).split(":").slice(0, -1).join(":") : "";
    const taskProjectPath2 = projectSegments ? `:${projectSegments}` : ":";
    const description = match[2]?.trim() || void 0;
    const existing = records.get(id);
    if (!existing) {
      if (records.size >= ANDROID_GRADLE_DISCOVERY_LIMITS.maxTasks) return errorSnapshot("Gradle task list exceeded the discovery limit.");
      records.set(id, { id, label: id, group, description, projectPath: taskProjectPath2, runnable: false, disabledReason: "Task execution is not enabled yet." });
    } else if (!existing.description && description) {
      records.set(id, { ...existing, description });
    }
  }
  if (malformed) return errorSnapshot("Gradle task output contained an overlong line.");
  if (records.size === 0) return errorSnapshot("Gradle output contained no recognizable tasks.");
  return { status: "ready", tasks: [...records.values()].sort((a, b) => a.id.localeCompare(b.id)) };
}
function errorSnapshot(error) {
  return { status: "error", tasks: [], error };
}
function stripAnsi(value) {
  return value.replace(/[\u001B\u009B]\[[0-?]*[ -/]*[@-~]/gu, "");
}

// src/execution.ts
function runnableGradleSnapshot(snapshot) {
  if (snapshot.status !== "ready") return snapshot;
  return { ...snapshot, tasks: snapshot.tasks.map((task) => ({ ...task, runnable: true, disabledReason: void 0, runState: "idle" })) };
}
function buildGradleTaskRunPlan(evidence, snapshot, taskId) {
  if (snapshot.status !== "ready" || !taskId || taskId.includes("\0")) return null;
  const task = snapshot.tasks.find((candidate) => candidate.id === taskId && candidate.runnable);
  const wrapper = buildGradleWrapperRequest(evidence);
  if (!task || !wrapper.supported) return null;
  return {
    pluginId: wrapper.request.pluginId,
    providerId: wrapper.request.providerId,
    taskId: task.id,
    label: task.label,
    executablePath: wrapper.request.executablePath,
    args: [task.id, ...ANDROID_GRADLE_EXECUTION_FLAGS]
  };
}
function applyGradleTaskResult(snapshot, taskId, result) {
  if (snapshot.status !== "ready") return snapshot;
  return {
    ...snapshot,
    tasks: snapshot.tasks.map((task) => task.id === taskId ? {
      ...task,
      runnable: true,
      disabledReason: void 0,
      runState: result.status
    } : task)
  };
}
function setGradleTaskRunState(snapshot, taskId, runState) {
  if (snapshot.status !== "ready") return snapshot;
  return {
    ...snapshot,
    tasks: snapshot.tasks.map((task) => ({
      ...task,
      runnable: true,
      disabledReason: void 0,
      runState: task.id === taskId ? runState : "idle"
    }))
  };
}

// src/sdk-compat.ts
var QUICK_KIND = "android.quickAction.kind";
var QUICK_MODULE = "android.quickAction.module";
var QUICK_VARIANT = "android.quickAction.variant";
function withQuickAction(task, quick) {
  return { ...task, metadata: { ...task.metadata ?? {}, [QUICK_KIND]: quick.kind, [QUICK_MODULE]: quick.module, [QUICK_VARIANT]: quick.variant } };
}
function readQuickAction(task) {
  const metadata = task.metadata;
  if (!metadata) return null;
  const kind = metadata[QUICK_KIND];
  const module = metadata[QUICK_MODULE];
  const variant = metadata[QUICK_VARIANT];
  return kind && module && variant && ["assemble", "bundle", "install", "uninstall"].includes(kind) ? { kind, module, variant } : null;
}
function withoutRunState(task) {
  const { runState: _runState, disabledReason: _disabledReason, runnable: _runnable, ...declarative } = task;
  return { ...declarative, runnable: false };
}

// src/quick-actions.ts
var ANDROID_GRADLE_QUICK_ACTION_LIMITS = Object.freeze({
  maxActions: 512,
  maxActionsPerKind: 128,
  maxCandidatesPerSelection: 32
});
var QUICK_ACTION_KINDS = ["assemble", "bundle", "install", "uninstall"];
var TASK_PATTERN = /^(assemble|bundle|install|uninstall)([A-Z][A-Za-z0-9_.-]*)$/u;
function deriveGradleQuickActions(snapshot) {
  if (snapshot.status !== "ready") return { status: "ready", actions: [], selections: [] };
  const actions = /* @__PURE__ */ new Map();
  const kindCounts = /* @__PURE__ */ new Map();
  for (const task of snapshot.tasks) {
    if (!task.runnable || !task.id || task.id.includes("\0")) continue;
    const parsed = readQuickAction(task) ?? parseTaskId(task.id);
    if (!parsed || !QUICK_ACTION_KINDS.includes(parsed.kind)) continue;
    const id = `${parsed.kind}:${task.id}`;
    if (actions.has(id) || actions.size >= ANDROID_GRADLE_QUICK_ACTION_LIMITS.maxActions || (kindCounts.get(parsed.kind) ?? 0) >= ANDROID_GRADLE_QUICK_ACTION_LIMITS.maxActionsPerKind) continue;
    actions.set(id, { id, taskId: task.id, module: parsed.module, variant: parsed.variant, kind: parsed.kind, label: `${parsed.kind} ${parsed.variant}` });
    kindCounts.set(parsed.kind, (kindCounts.get(parsed.kind) ?? 0) + 1);
  }
  const groupCounts = /* @__PURE__ */ new Map();
  const sorted = [...actions.values()].sort(compareActions).filter((action) => {
    const key = `${action.kind}:${action.variant}`;
    const count = groupCounts.get(key) ?? 0;
    if (count >= ANDROID_GRADLE_QUICK_ACTION_LIMITS.maxCandidatesPerSelection) return false;
    groupCounts.set(key, count + 1);
    return true;
  });
  const grouped = /* @__PURE__ */ new Map();
  for (const action of sorted) {
    const key = `${action.kind}:${action.variant}`;
    const group = grouped.get(key) ?? [];
    group.push(action);
    grouped.set(key, group);
  }
  const selections = [...grouped.entries()].filter(([, candidates]) => candidates.length > 1).map(([id, candidates]) => {
    const [kind, ...variantParts] = id.split(":");
    return { id, kind, variant: variantParts.join(":"), candidates };
  }).sort((a, b) => compareText(a.id, b.id));
  return { status: "ready", actions: sorted, selections };
}
function resolveGradleQuickAction(quickActions, kind, variant, module) {
  const actions = "actions" in quickActions ? quickActions.actions : quickActions;
  const candidates = actions.filter((action) => action.kind === kind && action.variant === variant && (module === void 0 || action.module === module));
  if (candidates.length === 1) return { status: "resolved", action: candidates[0] };
  if (candidates.length > 1) return { status: "ambiguous", candidates };
  return { status: "not-found" };
}
function gradleTaskArtifactHints(taskId) {
  const parsed = parseTaskId(taskId);
  if (!parsed || parsed.kind !== "assemble" && parsed.kind !== "bundle" && parsed.kind !== "install") return [];
  const modulePath = parsed.module === ":" ? "" : `${parsed.module.slice(1).replaceAll(":", "/")}/`;
  return [`${modulePath}build/outputs/${parsed.kind === "bundle" ? "bundle" : "apk"}`];
}
function parseTaskId(taskId) {
  if (!taskId.startsWith(":")) return null;
  const lastColon = taskId.lastIndexOf(":");
  const module = lastColon <= 0 ? ":" : taskId.slice(0, lastColon);
  if (module !== ":" && !/^:(?:[A-Za-z0-9_.-]+(?::[A-Za-z0-9_.-]+)*)$/u.test(module)) return null;
  const taskName = taskId.slice(lastColon + 1);
  const match = taskName.match(TASK_PATTERN);
  if (!match?.[1] || !match[2]) return null;
  return { module, kind: match[1], variant: match[2] };
}
function compareActions(left, right) {
  return compareText(left.taskId, right.taskId) || compareText(left.kind, right.kind) || compareText(left.id, right.id);
}
function compareText(left, right) {
  return left < right ? -1 : left > right ? 1 : 0;
}

// src/task-cache.ts
var ANDROID_GRADLE_CACHE_LIMITS = Object.freeze({ maxTasks: 32768, maxPayloadBytes: 16 * 1024 * 1024 });
function encodeAndroidGradleCachePayload(tasks, pluginId, pluginVersion, providerId) {
  if (tasks.length > ANDROID_GRADLE_CACHE_LIMITS.maxTasks) throw new Error("Android Gradle cache task count exceeds the limit.");
  const payload = {
    schemaVersion: 1,
    pluginId,
    pluginVersion,
    providerId,
    parserVersion: 1,
    discoveryProtocolVersion: 1,
    tasks: tasks.map(withoutRunState)
  };
  const text = JSON.stringify(payload);
  const bytes = new TextEncoder().encode(text);
  if (bytes.byteLength > ANDROID_GRADLE_CACHE_LIMITS.maxPayloadBytes) throw new Error("Android Gradle cache payload exceeds the limit.");
  const chunks = [];
  for (let offset = 0; offset < bytes.length; offset += 32768) {
    chunks.push(String.fromCharCode(...bytes.subarray(offset, offset + 32768)));
  }
  return btoa(chunks.join(""));
}
function decodeAndroidGradleCachePayload(payloadBase64, pluginId, pluginVersion, providerId) {
  if (typeof payloadBase64 !== "string" || payloadBase64.length === 0 || payloadBase64.length > Math.ceil(ANDROID_GRADLE_CACHE_LIMITS.maxPayloadBytes / 3) * 4) return null;
  try {
    const binary = atob(payloadBase64);
    if (binary.length > ANDROID_GRADLE_CACHE_LIMITS.maxPayloadBytes) return null;
    const bytes = Uint8Array.from(binary, (character) => character.charCodeAt(0));
    const source = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
    if (!source || typeof source !== "object" || Array.isArray(source)) return null;
    const record = source;
    if (record.schemaVersion !== 1 || record.pluginId !== pluginId || record.pluginVersion !== pluginVersion || record.providerId !== providerId || record.parserVersion !== 1 || record.discoveryProtocolVersion !== 1 || !Array.isArray(record.tasks) || record.tasks.length > ANDROID_GRADLE_CACHE_LIMITS.maxTasks) return null;
    const tasks = [];
    const taskIds = /* @__PURE__ */ new Set();
    for (const value of record.tasks) {
      if (!value || typeof value !== "object" || Array.isArray(value)) return null;
      const task = value;
      if (typeof task.id !== "string" || !task.id || task.id.length > 4096 || task.id.includes("\0") || !/^:[A-Za-z0-9_.-]+(?::[A-Za-z0-9_.-]+)*$/u.test(task.id) || typeof task.label !== "string" || task.label.length === 0 || task.label.length > 256 || task.label.includes("\0") || typeof task.group !== "string" || task.group.length === 0 || task.group.length > 256 || task.group.includes("\0") || typeof task.projectPath !== "string" || !/^:(?:[A-Za-z0-9_.-]+(?::[A-Za-z0-9_.-]+)*)?$/u.test(task.projectPath) || task.runnable !== false || task.runState !== void 0 || task.disabledReason !== void 0) return null;
      if (task.description !== void 0 && (typeof task.description !== "string" || task.description.length > 256 || task.description.includes("\0"))) return null;
      if (taskIds.has(task.id) || projectPathForTask(task.id) !== task.projectPath) return null;
      taskIds.add(task.id);
      const metadata = task.metadata;
      if (metadata !== void 0 && (!metadata || typeof metadata !== "object" || Array.isArray(metadata))) return null;
      const quick = metadata && typeof metadata === "object" && !Array.isArray(metadata) ? readQuickAction({ id: task.id, label: task.label, group: task.group, projectPath: task.projectPath, runnable: false, metadata }) : null;
      if (metadata !== void 0 && Object.keys(metadata).length > 16) return null;
      if (metadata !== void 0 && Object.entries(metadata).some(([key, value2]) => key.length > 128 || typeof value2 !== "string" || value2.length > 1024)) return null;
      if (quick && !isConsistentQuickAction(task.id, quick)) return null;
      tasks.push({
        id: task.id,
        label: task.label,
        group: task.group,
        projectPath: task.projectPath,
        ...task.description === void 0 ? {} : { description: task.description },
        runnable: false,
        ...metadata === void 0 ? {} : { metadata }
      });
    }
    return tasks;
  } catch {
    return null;
  }
}
function fingerprintPaths(files, platform) {
  const paths = files.map((file) => normalizePath(file.workspacePath, platform)).filter((path) => path !== null);
  return [...new Set(paths.filter(isFingerprintCandidate))].sort();
}
function normalizePath(value, platform) {
  if (!value || value.length > 4096 || value.includes("\0")) return null;
  const path = platform === "windows" ? value.replaceAll("\\", "/").toLowerCase() : value;
  if (path.startsWith("/") || /^[a-z]:\//u.test(path) || path.startsWith("//")) return null;
  const parts = path.split("/");
  if (parts.some((part) => !part || part === "." || part === "..")) return null;
  return parts.join("/");
}
function isFingerprintCandidate(path) {
  if (isGeneratedProjectPath(path)) return false;
  const base = path.slice(path.lastIndexOf("/") + 1);
  if (["build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts", "gradle.properties", "gradlew", "gradlew.bat", "AndroidManifest.xml", "androidmanifest.xml", "gradle-wrapper.properties", "libs.versions.toml"].includes(base)) return true;
  if (path.startsWith("gradle/") && base.endsWith(".toml")) return true;
  return path.startsWith("gradle/wrapper/") && base === "gradle-wrapper.properties" || (path.startsWith("buildSrc/") || path.startsWith("buildsrc/") || path.startsWith("build-logic/")) && (/\.(gradle|gradle\.kts|toml|properties|kt|kts|java)$/u.test(base) || /version/i.test(base));
}
function isGeneratedProjectPath(path) {
  return path.split("/").some((segment) => segment === "build" || segment === ".gradle" || segment === "out");
}
function intersectsFingerprintPaths(candidates, changed, platform) {
  const set = new Set(candidates);
  return changed.some((path) => {
    const normalized = normalizePath(path, platform);
    return normalized !== null && (set.has(normalized) || isFingerprintCandidate(normalized));
  });
}
function isConsistentQuickAction(taskId, value) {
  const kind = value.kind;
  const module = value.module;
  const variant = value.variant;
  if (!["assemble", "bundle", "install", "uninstall"].includes(kind) || typeof module !== "string" || module.length > 512 || typeof variant !== "string" || variant.length === 0 || variant.length > 512 || module.includes("\0") || variant.includes("\0") || !/^:(?:[A-Za-z0-9_.-]+(?::[A-Za-z0-9_.-]+)*)?$/.test(module) || !/^[A-Z][A-Za-z0-9_.-]*$/.test(variant)) return false;
  const match = taskId.match(/^((?::[A-Za-z0-9_.-]+(?::[A-Za-z0-9_.-]+)*)?):(assemble|bundle|install|uninstall)([A-Z][A-Za-z0-9_.-]*)$/u);
  return Boolean(match && match[2] === kind && (match[1] || ":") === module && match[3] === variant);
}
function projectPathForTask(taskId) {
  const segments = taskId.slice(1).split(":");
  return segments.length <= 1 ? ":" : `:${segments.slice(0, -1).join(":")}`;
}

// src/collection.ts
var ANDROID_GRADLE_COLLECTION_PROVIDER_ID = "gradle-tasks";
function buildAndroidGradleTaskCollection(snapshot) {
  const projects = /* @__PURE__ */ new Map();
  for (const task of snapshot.tasks) {
    const projectPath = taskProjectPath(task.id, task.projectPath);
    let project = projects.get(projectPath);
    if (!project) {
      project = { projectPath, groups: /* @__PURE__ */ new Map() };
      projects.set(projectPath, project);
    }
    const group = task.group.trim() || "Other";
    project.groups.set(group, [...project.groups.get(group) ?? [], task]);
  }
  const nodes = [];
  const orderedProjects = [...projects.values()].sort(compareProjects);
  orderedProjects.forEach((project, projectIndex) => {
    const projectId = project.projectPath === ":" ? "project.root" : stableId("project", project.projectPath);
    if (project.projectPath !== ":") {
      nodes.push({
        id: projectId,
        parentId: null,
        label: project.projectPath.slice(1) || project.projectPath,
        kind: "group",
        order: projectIndex * 1e5,
        metadata: { "android.gradle.nodeKind": "module", "android.gradle.projectPath": project.projectPath }
      });
    }
    [...project.groups.entries()].sort(([left], [right]) => compareText2(left, right)).forEach(([group, tasks], groupIndex) => {
      const groupId = `${projectId}.${stableId("group", group)}`;
      nodes.push({
        id: groupId,
        parentId: project.projectPath === ":" ? null : projectId,
        label: groupLabel(group),
        kind: "group",
        order: project.projectPath === ":" ? projectIndex * 1e5 + groupIndex : groupIndex,
        metadata: { "android.gradle.nodeKind": "group", "android.gradle.group": group }
      });
      [...tasks].sort((left, right) => compareText2(left.id, right.id)).forEach((task, taskIndex) => {
        nodes.push({
          id: `${groupId}.${stableId("task", task.id)}`,
          parentId: groupId,
          label: task.id,
          kind: "task",
          order: taskIndex,
          taskId: task.id,
          metadata: { "android.gradle.projectPath": project.projectPath, "android.gradle.group": group }
        });
      });
    });
  });
  return { providerId: ANDROID_GRADLE_COLLECTION_PROVIDER_ID, nodes, truncated: false };
}
function taskProjectPath(taskId, explicit) {
  if (explicit && /^:(?:[A-Za-z0-9_.-]+(?::[A-Za-z0-9_.-]+)*)?$/u.test(explicit)) return explicit;
  if (!taskId.startsWith(":")) return ":";
  const separator = taskId.lastIndexOf(":");
  return separator > 0 ? taskId.slice(0, separator) : ":";
}
function groupLabel(group) {
  const trimmed = group.replace(/\s+tasks$/iu, "").trim() || group.trim() || "Other";
  return trimmed.charAt(0).toLocaleLowerCase() + trimmed.slice(1);
}
function stableId(kind, value) {
  let hash = 0xcbf29ce484222325n;
  for (const byte of new TextEncoder().encode(value)) {
    hash ^= BigInt(byte);
    hash = BigInt.asUintN(64, hash * 0x100000001b3n);
  }
  return `${kind}.${hash.toString(16).padStart(16, "0")}`;
}
function compareProjects(left, right) {
  if (left.projectPath === ":" && right.projectPath !== ":") return -1;
  if (right.projectPath === ":" && left.projectPath !== ":") return 1;
  return compareText2(left.projectPath, right.projectPath);
}
function compareText2(left, right) {
  return left.localeCompare(right, void 0, { numeric: true, sensitivity: "base" });
}

// manifest.json
var manifest_default = {
  schemaVersion: 3,
  sdkMajor: 1,
  id: "dev.asterlyn.android-gradle",
  version: "0.5.8",
  nameKey: "name",
  descriptionKey: "description",
  localization: {
    defaultLocale: "en-US",
    locales: {
      "en-US": {
        name: "Android",
        description: "Android development tools for building, running, and inspecting devices.",
        "panel.run": "Run",
        "panel.tasks": "Tasks",
        "device.status.online": "Online",
        "device.status.offline": "Offline",
        "device.status.unauthorized": "Unauthorized",
        "device.status.unknown": "Unknown",
        "device.error.discovery": "Unable to discover Android devices.",
        "device.error.adbUnavailable": "ADB is unavailable.",
        "device.action.refresh": "Refresh devices",
        "device.action.retry": "Retry",
        "device.title": "Android devices",
        "device.loading": "Discovering Android devices\u2026",
        "device.empty": "No Android devices found.",
        "device.emptyDetail": "Connect a device or start an emulator, then refresh.",
        "device.count": "{count} detected",
        "run.empty": "No Android run configuration is available.",
        "run.loading": "Resolving Android run configuration\u2026",
        "run.error": "Android run configuration failed.",
        "run.configuration.select": "Run configuration",
        "run.target.select": "Target device",
        "run.action.start": "Run",
        "run.action.stop": "Stop",
        "run.configuration.androidApp": "Android app",
        "run.configuration.incomplete": "Run is unavailable until the plugin can authoritatively resolve the application ID and launcher activity.",
        "run.session.running": "Running Android application\u2026",
        "run.session.succeeded": "Android application launched.",
        "run.session.failed": "Android application Run failed.",
        "run.session.cancelled": "Android application Run was cancelled.",
        "run.session.crashed": "Android application Run crashed.",
        "run.phase.building": "Building application\u2026",
        "run.phase.resolving-artifact": "Resolving built APK\u2026",
        "run.phase.validating-target": "Validating selected device\u2026",
        "run.phase.installing": "Installing on selected device\u2026",
        "run.phase.awaiting-deployment-recovery": "Waiting for permission to replace the existing app\u2026",
        "run.phase.recovering-deployment": "Removing the incompatible existing app\u2026",
        "run.phase.launching": "Launching application\u2026",
        "run.recovery.uninstall.title": "Replace the existing application?",
        "run.recovery.uninstall.message": "The installed app has a different signature. It must be uninstalled before continuing. Uninstalling deletes its local data.",
        "run.recovery.uninstall.confirm": "Uninstall and continue",
        "run.recovery.uninstall.cancel": "Keep existing app",
        "settings.taskPresentation.label": "Task presentation",
        "settings.taskPresentation.description": "Choose the task tree shown in the Tasks tool window.",
        "settings.taskPresentation.allTasksTree": "All tasks tree",
        "settings.taskPresentation.quickActionsTree": "Android quick actions tree",
        "authorization.workspaceTrust.label": "Trust Gradle tasks in this workspace",
        "authorization.workspaceTrust.description": "Allow this plugin to run reviewed Gradle tasks in the current workspace. Turning this off also clears remembered task confirmations.",
        "authorization.rememberTask.label": "Do not ask again for this exact Gradle task",
        "authorization.rememberTask.description": "The approval is limited to this workspace and the current executable and arguments. Changes require confirmation again."
      },
      "zh-CN": {
        name: "Android",
        description: "\u7528\u4E8E\u6784\u5EFA\u3001\u8FD0\u884C\u548C\u67E5\u770B Android \u8BBE\u5907\u7684\u5F00\u53D1\u5DE5\u5177\u3002",
        "panel.run": "\u8FD0\u884C",
        "panel.tasks": "\u4EFB\u52A1",
        "device.status.online": "\u5728\u7EBF",
        "device.status.offline": "\u79BB\u7EBF",
        "device.status.unauthorized": "\u672A\u6388\u6743",
        "device.status.unknown": "\u672A\u77E5",
        "device.error.discovery": "\u65E0\u6CD5\u53D1\u73B0 Android \u8BBE\u5907\u3002",
        "device.error.adbUnavailable": "ADB \u4E0D\u53EF\u7528\u3002",
        "device.action.refresh": "\u5237\u65B0\u8BBE\u5907",
        "device.action.retry": "\u91CD\u8BD5",
        "device.title": "Android \u8BBE\u5907",
        "device.loading": "\u6B63\u5728\u53D1\u73B0 Android \u8BBE\u5907\u2026",
        "device.empty": "\u672A\u53D1\u73B0 Android \u8BBE\u5907\u3002",
        "device.emptyDetail": "\u8BF7\u8FDE\u63A5\u8BBE\u5907\u6216\u542F\u52A8\u6A21\u62DF\u5668\uFF0C\u7136\u540E\u5237\u65B0\u3002",
        "device.count": "\u5DF2\u53D1\u73B0 {count} \u53F0",
        "run.empty": "\u6CA1\u6709\u53EF\u7528\u7684 Android \u8FD0\u884C\u914D\u7F6E\u3002",
        "run.loading": "\u6B63\u5728\u89E3\u6790 Android \u8FD0\u884C\u914D\u7F6E\u2026",
        "run.error": "Android \u8FD0\u884C\u914D\u7F6E\u89E3\u6790\u5931\u8D25\u3002",
        "run.configuration.select": "\u8FD0\u884C\u914D\u7F6E",
        "run.target.select": "\u76EE\u6807\u8BBE\u5907",
        "run.action.start": "\u8FD0\u884C",
        "run.action.stop": "\u505C\u6B62",
        "run.configuration.androidApp": "Android \u5E94\u7528",
        "run.configuration.incomplete": "\u63D2\u4EF6\u5C1A\u672A\u53EF\u9760\u89E3\u6790\u5E94\u7528 ID \u548C\u542F\u52A8 Activity\uFF0C\u56E0\u6B64\u6682\u4E0D\u80FD\u8FD0\u884C\u3002",
        "run.session.running": "\u6B63\u5728\u8FD0\u884C Android \u5E94\u7528\u2026",
        "run.session.succeeded": "Android \u5E94\u7528\u5DF2\u542F\u52A8\u3002",
        "run.session.failed": "Android \u5E94\u7528\u8FD0\u884C\u5931\u8D25\u3002",
        "run.session.cancelled": "Android \u5E94\u7528\u8FD0\u884C\u5DF2\u53D6\u6D88\u3002",
        "run.session.crashed": "Android \u5E94\u7528\u8FD0\u884C\u5F02\u5E38\u7EC8\u6B62\u3002",
        "run.phase.building": "\u6B63\u5728\u6784\u5EFA\u5E94\u7528\u2026",
        "run.phase.resolving-artifact": "\u6B63\u5728\u5B9A\u4F4D\u6784\u5EFA\u751F\u6210\u7684 APK\u2026",
        "run.phase.validating-target": "\u6B63\u5728\u9A8C\u8BC1\u6240\u9009\u8BBE\u5907\u2026",
        "run.phase.installing": "\u6B63\u5728\u5B89\u88C5\u5230\u6240\u9009\u8BBE\u5907\u2026",
        "run.phase.awaiting-deployment-recovery": "\u6B63\u5728\u7B49\u5F85\u786E\u8BA4\u662F\u5426\u66FF\u6362\u5DF2\u6709\u5E94\u7528\u2026",
        "run.phase.recovering-deployment": "\u6B63\u5728\u5378\u8F7D\u7B7E\u540D\u4E0D\u517C\u5BB9\u7684\u5DF2\u6709\u5E94\u7528\u2026",
        "run.phase.launching": "\u6B63\u5728\u542F\u52A8\u5E94\u7528\u2026",
        "run.recovery.uninstall.title": "\u8981\u66FF\u6362\u5DF2\u6709\u5E94\u7528\u5417\uFF1F",
        "run.recovery.uninstall.message": "\u6240\u9009\u8BBE\u5907\u4E0A\u5DF2\u5B89\u88C5\u7684\u540C\u5305\u540D\u5E94\u7528\u4F7F\u7528\u4E86\u4E0D\u540C\u7B7E\u540D\u3002\u7EE7\u7EED\u5B89\u88C5\u524D\u5FC5\u987B\u5148\u5378\u8F7D\u5B83\uFF1B\u5378\u8F7D\u4F1A\u6E05\u9664\u8BE5\u5E94\u7528\u7684\u672C\u5730\u6570\u636E\u3002",
        "run.recovery.uninstall.confirm": "\u5378\u8F7D\u5E76\u7EE7\u7EED",
        "run.recovery.uninstall.cancel": "\u4FDD\u7559\u5DF2\u6709\u5E94\u7528",
        "settings.taskPresentation.label": "\u4EFB\u52A1\u5C55\u793A\u65B9\u5F0F",
        "settings.taskPresentation.description": "\u9009\u62E9\u4EFB\u52A1\u7A97\u53E3\u4E2D\u663E\u793A\u7684\u4EFB\u52A1\u6811\u3002",
        "settings.taskPresentation.allTasksTree": "\u5B8C\u6574\u4EFB\u52A1\u6811",
        "settings.taskPresentation.quickActionsTree": "Android \u5FEB\u6377\u64CD\u4F5C\u6811",
        "authorization.workspaceTrust.label": "\u4FE1\u4EFB\u6B64\u5DE5\u4F5C\u533A\u4E2D\u7684 Gradle \u4EFB\u52A1",
        "authorization.workspaceTrust.description": "\u5141\u8BB8\u6B64\u63D2\u4EF6\u5728\u5F53\u524D\u5DE5\u4F5C\u533A\u8FD0\u884C\u7ECF\u8FC7\u5BA1\u6838\u7684 Gradle \u4EFB\u52A1\u3002\u5173\u95ED\u540E\u4E5F\u4F1A\u6E05\u9664\u5DF2\u8BB0\u4F4F\u7684\u4EFB\u52A1\u786E\u8BA4\u3002",
        "authorization.rememberTask.label": "\u4E0D\u518D\u8BE2\u95EE\u8FD9\u4E2A\u7CBE\u786E\u7684 Gradle \u4EFB\u52A1",
        "authorization.rememberTask.description": "\u6388\u6743\u4EC5\u9650\u5F53\u524D\u5DE5\u4F5C\u533A\u4EE5\u53CA\u5F53\u524D\u53EF\u6267\u884C\u6587\u4EF6\u548C\u53C2\u6570\uFF1B\u53D1\u751F\u53D8\u5316\u65F6\u4F1A\u91CD\u65B0\u8BE2\u95EE\u3002"
      }
    }
  },
  settings: [{
    id: "taskPresentation",
    kind: "enum",
    labelKey: "settings.taskPresentation.label",
    descriptionKey: "settings.taskPresentation.description",
    defaultValue: "all-tasks-tree",
    options: [
      { value: "all-tasks-tree", labelKey: "settings.taskPresentation.allTasksTree" },
      { value: "quick-actions-tree", labelKey: "settings.taskPresentation.quickActionsTree" }
    ]
  }],
  taskAuthorization: {
    workspaceTrust: {
      id: "workspaceTrust",
      labelKey: "authorization.workspaceTrust.label",
      descriptionKey: "authorization.workspaceTrust.description"
    },
    taskConfirmation: {
      rememberLabelKey: "authorization.rememberTask.label",
      rememberDescriptionKey: "authorization.rememberTask.description"
    }
  },
  workspaceTool: {
    id: "android",
    titleKey: "name",
    icon: "device",
    views: [
      { id: "run", labelKey: "panel.run" },
      { id: "tasks", labelKey: "panel.tasks" }
    ],
    defaultView: "tasks"
  },
  hostOperations: [
    { id: "adb.devices" },
    { id: "android.apk.inspect" },
    { id: "android.adb.install" },
    { id: "android.adb.uninstall" },
    { id: "android.adb.launch" }
  ],
  capabilities: ["workspaceCatalog", "tasks", "taskCache", "taskAuthorization", "processQueries", "toolOperations", "workspaceState", "executionTargets", "runConfigurations"],
  permissions: ["host.workspace.catalog.read", "host.tasks.discover", "host.tasks.execute", "host.tasks.cache", "host.process.query", "host.tool.execute", "host.workspace.state", "host.execution-targets.read"],
  distribution: {
    repository: "guozhiqiang123/asterlyn-plugin-android-gradle",
    runtime: { protocol: 1, entry: "runtime/plugin.js" },
    hostCompatibility: { minimum: "0.1.15", maximumExclusive: "0.2.0" },
    license: { expression: "MIT", file: "LICENSE" },
    integrity: {}
  }
};

// src/manifest.ts
var ANDROID_GRADLE_PLUGIN_MANIFEST = Object.freeze(
  manifest_default
);

// src/devices.ts
var ANDROID_DEVICE_DISCOVERY_LIMITS = Object.freeze({
  maxOutputBytes: 512 * 1024,
  maxLineLength: 8 * 1024,
  maxDevices: 256
});
var STATUS_RANK = {
  online: 0,
  unknown: 1,
  offline: 2,
  unauthorized: 3
};
function parseAndroidDevicesOutput(output) {
  const bytes = typeof output === "string" ? new TextEncoder().encode(output) : output;
  if (bytes.byteLength > ANDROID_DEVICE_DISCOVERY_LIMITS.maxOutputBytes) {
    return errorResult("Android device discovery output exceeded the size limit.");
  }
  const text = new TextDecoder("utf-8", { fatal: false }).decode(bytes);
  const lines = text.split(/\r?\n/u);
  const records = /* @__PURE__ */ new Map();
  let headerFound = false;
  for (const rawLine of lines) {
    if (rawLine.length > ANDROID_DEVICE_DISCOVERY_LIMITS.maxLineLength) {
      return errorResult("Android device discovery output contained an overlong line.");
    }
    const line = rawLine.trim();
    if (!line) continue;
    if (!headerFound) {
      if (line === "List of devices attached") {
        headerFound = true;
        continue;
      }
      if (isDaemonPreamble(line)) continue;
      return errorResult("Android device discovery output was malformed before its header.");
    }
    const parsed = parseDeviceLine(line);
    if (!parsed) return errorResult("Android device discovery output contained a malformed device record.");
    const previous = records.get(parsed.serial);
    if (!previous) {
      if (records.size >= ANDROID_DEVICE_DISCOVERY_LIMITS.maxDevices) {
        return errorResult("Android device discovery returned too many devices.");
      }
      records.set(parsed.serial, parsed);
    } else if (STATUS_RANK[parsed.status] > STATUS_RANK[previous.status]) {
      records.set(parsed.serial, parsed);
    }
  }
  if (!headerFound) return errorResult("Android device discovery output did not contain its header.");
  return { status: "ready", devices: [...records.values()].sort((a, b) => a.serial.localeCompare(b.serial)) };
}
function parseDeviceLine(line) {
  const fields = line.split(/\s+/u);
  const serial = fields.shift();
  const statusToken = fields.shift();
  if (!serial || !statusToken || /\s/u.test(serial)) return null;
  const status = toStatus(statusToken);
  const metadata = {};
  for (const field of fields) {
    const separator = field.indexOf(":");
    if (separator <= 0 || separator === field.length - 1) return null;
    const key = field.slice(0, separator);
    const value = field.slice(separator + 1);
    if (!/^[A-Za-z_][A-Za-z0-9_.-]*$/u.test(key) || !value || value.includes(":") && key === "transport_id") return null;
    metadata[key] = value;
  }
  const emulator = /^emulator-\d+$/u.test(serial) || metadata.type === "emulator";
  const label = metadata.model ?? metadata.device ?? serial;
  const details = Object.entries(metadata).map(([key, value]) => `${key}=${value}`).join(", ");
  return {
    serial,
    label,
    detail: details || statusToken,
    status,
    selectable: status === "online",
    metadata: Object.freeze(metadata),
    emulator
  };
}
function toStatus(value) {
  if (value === "device") return "online";
  if (value === "offline") return "offline";
  if (value === "unauthorized") return "unauthorized";
  return "unknown";
}
function isDaemonPreamble(line) {
  return /^\* daemon (?:not running; starting now at tcp:\d+|started successfully|already running) \*$/u.test(line);
}
function errorResult(error) {
  return { status: "error", devices: [], error };
}

// src/device-provider.ts
var SELECTED_TARGET_KEY = "selectedDevice";
function createAndroidDeviceProvider(context) {
  const listeners = /* @__PURE__ */ new Set();
  let disposed = false;
  let revision = 0;
  let refreshInFlight = null;
  let selectedTargetId = null;
  let snapshot = context.processQueries ? { status: "loading", targets: [], selectedTargetId: null } : { status: "unavailable", targets: [], selectedTargetId: null, error: "ADB discovery is unavailable in this host." };
  const publish = () => {
    if (disposed) return;
    for (const listener of listeners) listener();
  };
  const refreshOnce = async () => {
    if (disposed || !context.processQueries) return;
    const current = ++revision;
    snapshot = { ...snapshot, status: "loading", error: void 0 };
    publish();
    try {
      const result = await context.processQueries.execute("adb.devices");
      if (disposed || current !== revision) return;
      if (result.status !== "succeeded") {
        snapshot = {
          status: result.status === "cancelled" ? "unavailable" : "error",
          targets: [],
          selectedTargetId: null,
          error: result.error ?? (result.stderr.trim() || `ADB device discovery ${result.status}.`)
        };
        publish();
        return;
      }
      if (result.truncated) {
        snapshot = { status: "error", targets: [], selectedTargetId: null, error: "ADB device discovery output was truncated." };
        publish();
        return;
      }
      const parsed = parseAndroidDevicesOutput(result.stdout);
      if (parsed.status === "error") {
        snapshot = { status: "error", targets: [], selectedTargetId: null, error: parsed.error };
        publish();
        return;
      }
      const targets = parsed.devices.map((device) => Object.freeze({
        id: device.serial,
        label: device.label,
        detail: device.detail,
        status: device.status,
        selectable: device.selectable,
        metadata: Object.freeze({ ...device.metadata, serial: device.serial, emulator: String(device.emulator) })
      }));
      if (!targets.some((target) => target.id === selectedTargetId && target.selectable)) {
        selectedTargetId = targets.find((target) => target.status === "online" && target.selectable)?.id ?? null;
      }
      snapshot = { status: "ready", targets: Object.freeze(targets), selectedTargetId };
      publish();
    } catch (error) {
      if (disposed || current !== revision) return;
      snapshot = {
        status: "error",
        targets: [],
        selectedTargetId: null,
        error: error instanceof Error ? error.message : String(error)
      };
      publish();
    }
  };
  const refresh = () => {
    if (refreshInFlight) return refreshInFlight;
    const tracked = refreshOnce().finally(() => {
      if (refreshInFlight === tracked) refreshInFlight = null;
    });
    refreshInFlight = tracked;
    return tracked;
  };
  const contribution = Object.freeze({
    kind: "execution-target-provider",
    id: "android-devices",
    snapshot: () => snapshot,
    subscribe: (listener) => {
      listeners.add(listener);
      return { dispose: () => {
        listeners.delete(listener);
      } };
    },
    refresh,
    select: async (targetId) => {
      if (targetId !== null && !snapshot.targets.some((target) => target.id === targetId && target.selectable)) {
        throw new Error(`Android device is not selectable: ${targetId}`);
      }
      selectedTargetId = targetId;
      snapshot = { ...snapshot, selectedTargetId };
      publish();
      await context.workspaceState?.write(SELECTED_TARGET_KEY, targetId ?? "");
    }
  });
  return {
    contribution,
    start: () => {
      void (async () => {
        try {
          const restored = await context.workspaceState?.read(SELECTED_TARGET_KEY);
          if (!disposed && restored) selectedTargetId = restored;
        } finally {
          if (!disposed) await refresh();
        }
      })();
    },
    dispose: () => {
      disposed = true;
      revision += 1;
      listeners.clear();
    }
  };
}

// src/run-configurations.ts
var ANDROID_RUN_CONFIGURATION_PROVIDER_ID = "android-run-configurations";
var ANDROID_RUN_TARGET_PROVIDER_ID = "android-devices";
function deriveAndroidRunConfigurations(snapshot) {
  const actions = deriveGradleQuickActions(snapshot).actions;
  const builds = new Map(actions.filter((action) => action.kind === "assemble").map((action) => [`${action.module}\0${action.variant}`, action]));
  return actions.filter((action) => action.kind === "install" && !action.variant.endsWith("AndroidTest")).flatMap((install) => {
    const build = builds.get(`${install.module}\0${install.variant}`);
    if (!build) return [];
    const moduleLabel = install.module === ":" ? "root" : install.module.slice(1);
    const id = `android-run:${install.taskId}`;
    return Object.freeze({
      id,
      taskId: build.taskId,
      installTaskId: install.taskId,
      module: install.module,
      variant: install.variant,
      descriptor: Object.freeze({
        id,
        label: `${moduleLabel} \xB7 ${install.variant}`,
        detail: build.taskId,
        status: "ready",
        targetProviderId: ANDROID_RUN_TARGET_PROVIDER_ID,
        metadata: Object.freeze({ module: install.module, variant: install.variant, taskId: build.taskId, installTaskId: install.taskId })
      })
    });
  });
}
function androidRunConfigurationSnapshot(tasks, preferredConfigurationId) {
  if (tasks.status === "loading") return { status: "loading", configurations: [], selectedConfigurationId: null };
  if (tasks.status === "error") {
    return { status: "error", configurations: [], selectedConfigurationId: null, error: tasks.error ?? "Gradle task discovery failed." };
  }
  const configurations = deriveAndroidRunConfigurations(tasks);
  const selected = configurations.some((configuration) => configuration.id === preferredConfigurationId) ? preferredConfigurationId : configurations[0]?.id ?? null;
  return { status: "ready", configurations: configurations.map((configuration) => configuration.descriptor), selectedConfigurationId: selected };
}
function buildAndroidStagedRunPlan(build, targetId, variant, apply) {
  let selectedArtifact = null;
  let buildOutputUsable = false;
  const buildApply = build.apply;
  const supervisedBuild = {
    ...build,
    artifactSearch: {
      hints: build.artifactSearch?.hints ?? [],
      sidecarNames: ["output-metadata.json"]
    },
    apply: (result) => {
      buildOutputUsable = result.status === "succeeded" && !result.truncated;
      buildApply(result);
    }
  };
  return Object.freeze({
    kind: "staged",
    build: supervisedBuild,
    inspect: (artifacts, sidecars, truncated) => {
      if (!buildOutputUsable || truncated) return null;
      selectedArtifact = resolveAgpSingleApkArtifact(artifacts, sidecars, variant);
      return selectedArtifact ? { operationId: "android.apk.inspect", parameters: { artifact: selectedArtifact.workspacePath } } : null;
    },
    deploy: (inspection) => {
      if (!selectedArtifact || inspection.status !== "succeeded" || inspection.truncated) return null;
      return {
        operationId: "android.adb.install",
        parameters: { target: targetId, artifact: selectedArtifact.workspacePath }
      };
    },
    recoverDeployment: async (inspection, deployment) => {
      const launch = parseAndroidLaunchComponent(inspection.stdout);
      if (!launch) return null;
      const { buildUpdateIncompatibleRecovery: buildUpdateIncompatibleRecovery2 } = await Promise.resolve().then(() => (init_deployment_recovery(), deployment_recovery_exports));
      return buildUpdateIncompatibleRecovery2(deployment, targetId, launch.applicationId);
    },
    launch: (inspection) => {
      if (inspection.status !== "succeeded" || inspection.truncated) return null;
      const launch = parseAndroidLaunchComponent(inspection.stdout);
      return launch ? {
        operationId: "android.adb.launch",
        parameters: { target: targetId, component: launch.component }
      } : null;
    },
    apply
  });
}
function resolveAgpSingleApkArtifact(artifacts, sidecars, variant) {
  if (!variant || variant.length > 256 || !/^[A-Za-z0-9_.-]+$/u.test(variant)) return null;
  const agpVariantName = `${variant[0].toLowerCase()}${variant.slice(1)}`;
  const artifactByPath = new Map(
    artifacts.filter((artifact) => artifact.kind === "apk" && artifact.workspacePath.endsWith(".apk")).map((artifact) => [artifact.workspacePath, artifact])
  );
  const matches = [];
  for (const sidecar of sidecars) {
    if (!sidecar.workspacePath.endsWith("/output-metadata.json")) continue;
    const metadata = parseAgpOutputMetadata(decodeBase64Utf8(sidecar.dataBase64));
    if (!metadata || metadata.variantName !== agpVariantName || metadata.outputFile.includes("/") || metadata.outputFile.includes("\\")) continue;
    const directory = sidecar.workspacePath.slice(0, sidecar.workspacePath.lastIndexOf("/") + 1);
    const artifact = artifactByPath.get(`${directory}${metadata.outputFile}`);
    if (artifact) matches.push(artifact);
  }
  return matches.length === 1 ? matches[0] ?? null : null;
}
function parseAgpOutputMetadata(text) {
  if (!text || text.length > 65536) return null;
  try {
    const value = JSON.parse(text);
    if (value.artifactType && (typeof value.artifactType !== "object" || value.artifactType.type !== "APK")) return null;
    if (typeof value.variantName !== "string" || !Array.isArray(value.elements) || value.elements.length !== 1) return null;
    const element = value.elements[0];
    if (!element || typeof element !== "object") return null;
    const record = element;
    if (record.type !== "SINGLE" || typeof record.outputFile !== "string" || !record.outputFile.endsWith(".apk") || record.outputFile.length > 512) return null;
    return Object.freeze({ variantName: value.variantName, outputFile: record.outputFile });
  } catch {
    return null;
  }
}
function parseAndroidLaunchComponent(output) {
  const applicationId = output.match(/^package:\s+name='([^']+)'/mu)?.[1] ?? null;
  const activities = new Set(
    [...output.matchAll(/^(?:launchable-activity|leanback-launchable-activity):\s+name='([^']+)'/gmu)].map((match) => match[1]).filter((value) => Boolean(value))
  );
  const declaredActivity = activities.size === 1 ? [...activities][0] ?? null : null;
  if (!applicationId || !declaredActivity || !validAndroidName(applicationId)) return null;
  const activityName = declaredActivity.startsWith(".") ? `${applicationId}${declaredActivity}` : declaredActivity.includes(".") ? declaredActivity : `${applicationId}.${declaredActivity}`;
  if (!validAndroidName(activityName)) return null;
  return Object.freeze({ applicationId, activityName, component: `${applicationId}/${activityName}` });
}
function decodeBase64Utf8(value) {
  try {
    const binary = globalThis.atob(value);
    const bytes = Uint8Array.from(binary, (character) => character.charCodeAt(0));
    return new TextDecoder("utf-8", { fatal: false }).decode(bytes);
  } catch {
    return null;
  }
}
function validAndroidName(value) {
  return value.length <= 512 && value.split(".").every(
    (part) => part.length > 0 && [...part].every(
      (character, index) => /[A-Za-z_]/u.test(character) || index > 0 && /[0-9$]/u.test(character)
    )
  );
}

// src/plugin.ts
var ANDROID_GRADLE_PLUGIN_ID = ANDROID_GRADLE_PLUGIN_MANIFEST.id;
var ANDROID_GRADLE_PLUGIN = Object.freeze({
  sdkMajor: ANDROID_GRADLE_PLUGIN_MANIFEST.sdkMajor,
  id: ANDROID_GRADLE_PLUGIN_ID,
  version: ANDROID_GRADLE_PLUGIN_MANIFEST.version,
  manifest: ANDROID_GRADLE_PLUGIN_MANIFEST,
  matches: (context) => {
    const evidence = detectAndroidGradlePluginEvidence(context);
    return evidence !== null && isRunnableGradleWorkspace(evidence);
  },
  evidenceKey: (context) => {
    const evidence = detectAndroidGradlePluginEvidence(context);
    const catalog = catalogEvidence(context.evidence);
    return evidence ? JSON.stringify([
      evidence.platform,
      evidence.bounded,
      evidence.catalogTruncated,
      evidence.gradle,
      evidence.android,
      evidence.wrapper,
      evidence.evidence,
      catalog ? fingerprintPaths(catalog.files, catalog.platform) : []
    ]) : "unsupported";
  },
  activate: (context) => {
    const detected = detectAndroidGradlePluginEvidence(context);
    if (!detected || !isRunnableGradleWorkspace(detected)) return;
    const detection = detected;
    const cache = context.taskCache;
    const catalog = catalogEvidence(context.evidence)?.files ?? [];
    const cachePaths = fingerprintPaths(catalog, detection.platform);
    const listeners = /* @__PURE__ */ new Set();
    let disposed = false;
    let revision = 0;
    let selectedRunConfigurationId = null;
    let currentFingerprint = null;
    const cacheMissReason = "cache-miss";
    const publish = () => {
      if (disposed) return;
      for (const listener of listeners) listener();
    };
    const metadata = (status, staleReason, restoredTaskCount) => ({
      status,
      ...staleReason ? { staleReason } : {},
      ...restoredTaskCount === void 0 ? {} : { restoredTaskCount }
    });
    let snapshot = {
      status: cache ? "ready" : "unavailable",
      tasks: [],
      ...cache ? { cache: metadata("validating") } : { unavailableReason: detection.catalogTruncated ? "evidence-incomplete" : "discovery-not-supported" }
    };
    const provider = {
      kind: "provider",
      id: "gradle-tasks",
      label: "Gradle",
      settingsFocus: "taskPresentation",
      snapshot: () => snapshot,
      collections: () => [buildAndroidGradleTaskCollection(snapshot)],
      subscribe: (listener) => {
        listeners.add(listener);
        return { dispose: () => listeners.delete(listener) };
      },
      invalidate: (invalidation) => {
        if (!cache || disposed) return;
        const reason = invalidation.recovery === "none" ? intersectsFingerprintPaths(cachePaths, invalidation.paths, detection.platform) ? "watcher-change" : null : "overflow-recovery";
        if (!reason) return;
        revision += 1;
        snapshot = { ...snapshot, cache: metadata("stale", reason), tasks: disableTasks(snapshot.tasks) };
        currentFingerprint = null;
        publish();
        return cache.markDirty("gradle-tasks", reason === "overflow-recovery" ? "watcher-ambiguous" : "workspace-change").then(() => void 0, () => void 0);
      },
      refresh: () => {
        if (disposed) return null;
        const refreshRevision = ++revision;
        const retainedTasks = snapshot.tasks;
        const prepared = buildGradleWrapperRequest(detection);
        if (!prepared.supported) {
          snapshot = { status: "unavailable", tasks: disableTasks(retainedTasks), cache: metadata("stale", "fingerprint-unavailable"), unavailableReason: prepared.reason === "wrapper-missing" ? "discovery-not-supported" : "evidence-incomplete" };
          publish();
          return null;
        }
        const plan = {
          request: prepared.request,
          apply: (result) => {
            if (disposed || revision !== refreshRevision) return;
            if (result.status !== "succeeded") {
              snapshot = { status: "error", tasks: disableTasks(retainedTasks), cache: metadata("stale", "refresh-failed"), error: result.error ?? (result.status === "cancelled" ? "Gradle task discovery was cancelled." : `Gradle task discovery ${result.status}.`) };
              publish();
              return;
            }
            if (result.truncated) {
              snapshot = { status: "error", tasks: disableTasks(retainedTasks), cache: metadata("stale", "refresh-failed"), error: "Gradle task discovery output was truncated." };
              publish();
              return;
            }
            const chunks = [];
            let byteLength = 0;
            for (const output of result.outputs) {
              if (output.stream !== "stdout") continue;
              try {
                const binary = atob(output.dataBase64);
                byteLength += binary.length;
                if (byteLength > ANDROID_GRADLE_DISCOVERY_LIMITS.maxOutputBytes) {
                  snapshot = { status: "error", tasks: disableTasks(retainedTasks), cache: metadata("stale", "refresh-failed"), error: "Gradle task discovery output exceeded the discovery limit." };
                  publish();
                  return;
                }
                chunks.push(Uint8Array.from(binary, (character) => character.charCodeAt(0)));
              } catch {
                snapshot = { status: "error", tasks: disableTasks(retainedTasks), cache: metadata("stale", "refresh-failed"), error: "Gradle task discovery output was invalid." };
                publish();
                return;
              }
            }
            const bytes = new Uint8Array(byteLength);
            let offset = 0;
            for (const chunk of chunks) {
              bytes.set(chunk, offset);
              offset += chunk.byteLength;
            }
            const parsed = parseGradleTasksOutput(bytes);
            if (parsed.status !== "ready") {
              snapshot = { ...parsed, tasks: disableTasks(retainedTasks), cache: metadata("stale", "refresh-failed") };
              publish();
              return;
            }
            const discovered = withGradleQuickActions(runnableGradleSnapshot(parsed));
            snapshot = { ...discovered, tasks: discovered.tasks.map((task) => ({ ...task, runnable: false })), ...cache ? { cache: metadata("validating", void 0, discovered.tasks.length) } : {} };
            publish();
            if (cache) void finalizeRefresh(discovered.tasks, refreshRevision);
          }
        };
        snapshot = { status: "loading", tasks: retainedTasks };
        publish();
        return plan;
      },
      run: async (taskId) => {
        if (disposed) return null;
        if (cache) {
          const fingerprint = await cache.computeFingerprint(cachePaths);
          if (disposed) return null;
          if (fingerprint.status !== "ready" || !currentFingerprint || fingerprint.digest !== currentFingerprint.digest) {
            snapshot = { ...snapshot, cache: metadata("stale", "fingerprint-mismatch"), tasks: snapshot.tasks.map((task) => ({ ...task, runnable: false })) };
            currentFingerprint = null;
            publish();
            return null;
          }
        }
        const plan = buildGradleTaskRunPlan(detection, snapshot, taskId);
        if (!plan) return null;
        snapshot = setGradleTaskRunState(snapshot, taskId, "queued");
        const artifactHints = gradleTaskArtifactHints(taskId);
        return {
          request: plan,
          ...artifactHints.length > 0 ? { artifactSearch: { hints: artifactHints } } : {},
          apply: (result) => {
            snapshot = applyGradleTaskResult(snapshot, taskId, result);
            publish();
          }
        };
      }
    };
    const providerDisposable = context.contribute(provider);
    const commandDisposable = context.contribute({
      kind: "command",
      id: "refresh-gradle-tasks",
      providerId: "gradle-tasks",
      title: () => "Gradle",
      detail: () => "Gradle",
      execute: () => void 0
    });
    const devices = createAndroidDeviceProvider(context);
    const deviceDisposable = context.contribute(devices.contribution);
    const runConfigurationDisposable = context.contribute({
      kind: "run-configuration-provider",
      id: ANDROID_RUN_CONFIGURATION_PROVIDER_ID,
      snapshot: () => androidRunConfigurationSnapshot(
        detection.android ? snapshot : { status: "ready", tasks: [] },
        selectedRunConfigurationId
      ),
      subscribe: (listener) => {
        listeners.add(listener);
        return { dispose: () => {
          listeners.delete(listener);
        } };
      },
      select: async (configurationId) => {
        if (configurationId !== null && (!detection.android || !deriveAndroidRunConfigurations(snapshot).some((configuration) => configuration.id === configurationId))) {
          throw new Error(`Android run configuration is unavailable: ${configurationId}`);
        }
        selectedRunConfigurationId = configurationId;
        publish();
        await context.workspaceState?.write("selectedRunConfiguration", configurationId ?? "");
      },
      run: async (configurationId, targetId) => {
        if (!detection.android || !targetId) return null;
        const configuration = deriveAndroidRunConfigurations(snapshot).find((candidate) => candidate.id === configurationId);
        if (!configuration) return null;
        const build = await provider.run(configuration.taskId);
        if (!build?.artifactSearch?.hints.length) return null;
        return buildAndroidStagedRunPlan(build, targetId, configuration.variant, (result) => {
          snapshot = setGradleTaskRunState(snapshot, configuration.taskId, result.status);
          publish();
        });
      }
    });
    devices.start();
    void context.workspaceState?.read("selectedRunConfiguration").then((restored) => {
      if (disposed) return;
      selectedRunConfigurationId = restored || null;
      publish();
    }, () => void 0);
    if (cache) void restoreFromCache(revision);
    async function restoreFromCache(restoreRevision) {
      try {
        const read = await cache.read("gradle-tasks");
        if (disposed || revision !== restoreRevision) return;
        const tasks = decodeAndroidGradleCachePayload(read.payloadBase64, ANDROID_GRADLE_PLUGIN_ID, ANDROID_GRADLE_PLUGIN.manifest.version, "gradle-tasks");
        if (!tasks) {
          snapshot = { status: "ready", tasks: [], cache: metadata("stale", read.status === "unavailable" ? "fingerprint-unavailable" : read.status === "miss" ? cacheMissReason : "cache-corrupt") };
          publish();
          return;
        }
        if (!detection.bounded || detection.catalogTruncated) {
          snapshot = { status: "ready", tasks: gradleTasks(tasks), cache: metadata("stale", "fingerprint-unavailable", tasks.length) };
          publish();
          return;
        }
        if (read.status !== "fresh") {
          const staleReason = read.status === "stale" ? read.staleReason === "expired" || read.staleReason === "future-timestamp" ? "cache-expired" : "cache-corrupt" : read.status === "dirty" ? read.dirtyReason === "watcher-ambiguous" ? "overflow-recovery" : read.dirtyReason === "manual" || read.dirtyReason === "unknown" ? cacheMissReason : "watcher-change" : read.status === "unavailable" ? "fingerprint-unavailable" : read.status === "miss" ? cacheMissReason : "cache-corrupt";
          snapshot = { status: "ready", tasks: gradleTasks(tasks), cache: metadata("stale", staleReason, tasks.length) };
          publish();
          return;
        }
        snapshot = { status: "ready", tasks: gradleTasks(tasks), cache: metadata("validating", void 0, tasks.length) };
        publish();
        const fingerprint = await cache.computeFingerprint(cachePaths);
        if (disposed || revision !== restoreRevision) return;
        currentFingerprint = fingerprint.status === "ready" ? fingerprint : null;
        const match = fingerprint.status === "ready" && read.fingerprint?.digest === fingerprint.digest && read.status === "fresh";
        snapshot = { status: "ready", tasks: match ? gradleTasks(tasks).map((task) => ({ ...task, runnable: true })) : gradleTasks(tasks), cache: match ? metadata("ready", void 0, tasks.length) : metadata("stale", fingerprint.status === "ready" ? "fingerprint-mismatch" : "fingerprint-unavailable", tasks.length) };
        if (!match) currentFingerprint = null;
        publish();
      } catch {
        if (disposed) return;
        snapshot = { status: "ready", tasks: [], cache: metadata("stale", "cache-corrupt") };
        publish();
      }
    }
    async function finalizeRefresh(tasks, refreshRevision) {
      try {
        const fingerprint = await cache.computeFingerprint(cachePaths);
        if (disposed || revision !== refreshRevision) return;
        if (fingerprint.status !== "ready") {
          snapshot = { ...snapshot, cache: metadata("stale", "fingerprint-unavailable") };
          publish();
          return;
        }
        const payload = encodeAndroidGradleCachePayload(tasks, ANDROID_GRADLE_PLUGIN_ID, ANDROID_GRADLE_PLUGIN.manifest.version, "gradle-tasks");
        const stored = await cache.write("gradle-tasks", fingerprint, payload);
        if (disposed || revision !== refreshRevision) return;
        if (stored.status !== "stored") {
          snapshot = { ...snapshot, cache: metadata("stale", "cache-corrupt") };
          publish();
          return;
        }
        currentFingerprint = fingerprint;
        snapshot = { ...snapshot, status: "ready", tasks: gradleTasks(tasks).map((task) => ({ ...task, runnable: true })), cache: metadata("ready", void 0, tasks.length) };
        publish();
      } catch {
        if (disposed) return;
        snapshot = { ...snapshot, cache: metadata("stale", "cache-corrupt") };
        publish();
      }
    }
    function gradleTasks(tasks) {
      return tasks.map((task) => ({ ...task, projectPath: task.projectPath ?? ":" }));
    }
    function disableTasks(tasks) {
      return gradleTasks(tasks).map((task) => ({ ...task, runnable: false }));
    }
    return {
      dispose: () => {
        disposed = true;
        listeners.clear();
        void providerDisposable.dispose();
        void commandDisposable.dispose();
        devices.dispose();
        void deviceDisposable.dispose();
        void runConfigurationDisposable.dispose();
      }
    };
  }
});
function withGradleQuickActions(snapshot) {
  if (snapshot.status !== "ready") return snapshot;
  const quickActions = new Map(deriveGradleQuickActions(snapshot).actions.map((action) => [action.taskId, action]));
  return {
    ...snapshot,
    tasks: snapshot.tasks.map((task) => {
      const quick = quickActions.get(task.id);
      return quick ? withQuickAction(task, { kind: quick.kind, module: quick.module, variant: quick.variant }) : task;
    })
  };
}
function detectAndroidGradlePluginEvidence(context) {
  const catalog = catalogEvidence(context.evidence);
  if (!catalog) return null;
  return detectAndroidGradleEvidence({
    workspaceRoot: context.identity.root,
    generation: context.identity.generation,
    platform: catalog.platform,
    files: catalog.files,
    catalogTruncated: catalog.truncated
  });
}
function catalogEvidence(evidence) {
  const value = Array.isArray(evidence) ? evidence.find((candidate) => Boolean(candidate && typeof candidate === "object" && candidate.kind === "workspace-catalog"))?.values : evidence && typeof evidence === "object" && evidence.kind === "workspace-catalog" ? evidence : null;
  if (!value) return null;
  const platform = value.platform;
  const truncated = value.truncated;
  const files = value.files;
  if (platform !== "posix" && platform !== "windows" || typeof truncated !== "boolean" || !Array.isArray(files)) return null;
  const paths = files.map((file) => typeof file === "string" ? file : file && typeof file === "object" && typeof file.workspacePath === "string" ? file.workspacePath : null);
  if (paths.some((file) => file === null)) return null;
  return { platform, truncated, files: paths.map((workspacePath) => ({ workspacePath })) };
}
export {
  ANDROID_DEVICE_DISCOVERY_LIMITS,
  ANDROID_GRADLE_COLLECTION_PROVIDER_ID,
  ANDROID_GRADLE_DETECTOR_LIMITS,
  ANDROID_GRADLE_DISCOVERY_LIMITS,
  ANDROID_GRADLE_EXECUTION_FLAGS,
  ANDROID_GRADLE_PLUGIN,
  ANDROID_GRADLE_PLUGIN_ID,
  ANDROID_GRADLE_PLUGIN_MANIFEST,
  ANDROID_GRADLE_QUICK_ACTION_LIMITS,
  ANDROID_GRADLE_TASK_ARGS,
  ANDROID_RUN_CONFIGURATION_PROVIDER_ID,
  ANDROID_RUN_TARGET_PROVIDER_ID,
  androidRunConfigurationSnapshot,
  applyGradleTaskResult,
  buildAndroidGradleTaskCollection,
  buildAndroidStagedRunPlan,
  buildGradleTaskRunPlan,
  buildGradleWrapperRequest,
  createAndroidDeviceProvider,
  deriveAndroidRunConfigurations,
  deriveGradleQuickActions,
  detectAndroidGradleEvidence,
  detectAndroidGradlePluginEvidence,
  gradleTaskArtifactHints,
  parseAgpOutputMetadata,
  parseAndroidDevicesOutput,
  parseAndroidLaunchComponent,
  parseGradleTasksOutput,
  resolveAgpSingleApkArtifact,
  resolveGradleQuickAction,
  runnableGradleSnapshot,
  setGradleTaskRunState
};
