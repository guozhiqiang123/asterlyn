// Internal backend policy. The host separately supervises this adapter process.
export class RecoveryBudget {
  #attempts=0;
  #healthySince=null;
  #now;
  constructor(now=()=>performance.now()){this.#now=now;}
  healthy(ready){if(!ready)this.#healthySince=null;else this.#healthySince??=this.#now();}
  reserve(reason){
    if(this.#healthySince!==null&&this.#now()-this.#healthySince>=180000)this.#attempts=0;
    this.#healthySince=null;
    if(!["java-backend-exited","kotlin-backend-exited"].includes(reason)||this.#attempts>=3)return null;
    const delayMs=[500,1000,2000][this.#attempts++];
    return {attempt:this.#attempts,maximum:3,delayMs,reason};
  }
}

/** Stale model attempts may settle after a newer input arrived. Never retry configuration errors. */
export class ModelRecoveryBudget {
  #attempts=0;
  reset(){this.#attempts=0;}
  reserve(reason){
    if(!["model-obsolete","model-inputs-changed","model-busy"].includes(reason)||this.#attempts>=2)return null;
    return {attempt:++this.#attempts,maximum:2,delayMs:[600,1500][this.#attempts-1],reason};
  }
}
