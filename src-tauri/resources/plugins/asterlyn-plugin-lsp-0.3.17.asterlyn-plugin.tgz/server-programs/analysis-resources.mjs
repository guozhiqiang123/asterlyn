/** Private host-mediated admission; the descriptor receives no process or filesystem authority. */
export function compilerHeaps({files=0,bytes=0},policy){
  if(policy?.schema!==1||!Number.isSafeInteger(policy.maxHeapMiB)||policy.maxHeapMiB<512||policy.maxHeapMiB>8192)throw Error("analysis-resource-policy-unavailable");
  const initial=Math.min(policy.maxHeapMiB,files>1000||bytes>16*1024*1024?2048:files>200||bytes>4*1024*1024?1024:768);
  return [initial,...(initial<policy.maxHeapMiB?[policy.maxHeapMiB]:[])];
}
export function hostAnalysisResources(peer,policy){
  compilerHeaps({},policy);
  return {policy,
    reserve:async(memoryMiB,signal)=>{
      const result=await peer.request("asterlyn/analysisResources.reserve",{memoryMiB},125000,signal);
      if(typeof result?.leaseId!=="string"||!/^resource-[0-9]{1,20}$/u.test(result.leaseId))throw Error("analysis-resource-lease-invalid");
      return result.leaseId;
    },release:leaseId=>peer.notify("asterlyn/analysisResources.release",{leaseId})};
}
export function compilerFailure(error,signal){
  if(signal?.aborted||error?.name==="AbortError")return "kapt-generation-cancelled";
  // Exit 137 alone is ambiguous: escalate only confirmed heap exhaustion.
  if(/(?:java\.lang\.)?OutOfMemoryError:\s*(?:Java heap space|GC overhead limit exceeded)/u.test(String(error?.stderr??"").slice(-32768)))return "kotlin-compiler-resource-limit";
  return error?.killed?"kotlin-compiler-timeout":"kotlin-compiler-failed";
}
export async function runCompiler({resources,workload,signal,execute,reset=async()=>{},onEvent=()=>{},onWaiting=()=>{},onRunning=()=>{}}){
  const heaps=compilerHeaps(workload,resources?.policy);
  for(const [index,heapMiB]of heaps.entries()){
    if(signal?.aborted)throw Error("kapt-generation-cancelled");
    let lease;const started=performance.now();
    try{
      onWaiting();onEvent({code:"compiler-resource-wait",heapMiB,memoryMiB:heapMiB+512,attempt:index+1});
      lease=await resources.reserve(heapMiB+512,signal);
      if(signal?.aborted)throw Error("kapt-generation-cancelled");
      onRunning();onEvent({code:"compiler-started",heapMiB,attempt:index+1,files:workload.files,bytes:workload.bytes});
      try{await execute(heapMiB);onEvent({code:"compiler-completed",heapMiB,attempt:index+1,durationMs:Math.round(performance.now()-started)});return;}
      catch(error){const code=compilerFailure(error,signal);onEvent({code,heapMiB,attempt:index+1,durationMs:Math.round(performance.now()-started)});
        if(code!=="kotlin-compiler-resource-limit"||index+1>=heaps.length)throw Error(code);
      }
    }finally{if(lease!==undefined)await resources.release(lease);}
    // Inputs and the argument file remain fixed; only incomplete outputs are removed.
    await reset();onEvent({code:"compiler-memory-retry",heapMiB:heaps[index+1],attempt:index+2});
  }
}
