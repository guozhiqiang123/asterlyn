/** Retains at most 128 characters, emits no server text, and prevents OOM restart loops. */
export class JvmFailureClassifier {
  #tail="";
  resourceLimit=false;
  observe(chunk){
    const text=this.#tail+String(chunk);
    if(text.includes("java.lang.OutOfMemoryError"))this.resourceLimit=true;
    this.#tail=text.slice(-128);
  }
}
