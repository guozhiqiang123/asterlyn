// server-programs/model.mjs
import { spawn, spawnSync } from "node:child_process";
import { mkdtemp, mkdir, readdir, readFile, realpath, rm, stat, symlink } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

// server-programs/normalize-model.mjs
var LIMITS = Object.freeze({ modules: 256, paths: 2e4, pathLength: 4096, bytes: 8 * 1024 * 1024 });
var MODULE = /^:(?:[A-Za-z0-9_.-]+(?::[A-Za-z0-9_.-]+)*)?$/u;
var VARIANT = /^[A-Za-z0-9_][A-Za-z0-9_.-]{0,159}$/u;
var record = (value) => {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("invalid model object");
  return value;
};
var absolutePath = (value) => {
  if (typeof value !== "string" || value.length > LIMITS.pathLength || /[\u0000-\u001f]/u.test(value) || !/^(?:\/|[A-Za-z]:[\\/]|\\\\[^\\]+\\[^\\]+)/u.test(value) || value.split(/[\\/]/u).some((part) => part === "." || part === "..")) throw new Error("invalid model path");
  return value;
};
var selection = (value) => {
  if (!MODULE.test(value.module) || !VARIANT.test(value.variant)) throw new Error("invalid model selection");
  return { module: value.module, variant: value.variant };
};
var version = (value) => {
  if (typeof value !== "string" || value.length > 64 || !/^\d+\.\d+(?:\.\d+)?(?:[-.][A-Za-z0-9]+)*$/u.test(value)) throw new Error("invalid model version");
  return value;
};
function normalizeAgpV2LanguageModel(raw, metadata) {
  const rootValue = absolutePath(metadata.buildRoot);
  const root = /^\/$|^(?:[A-Za-z]:[\\/])$/u.test(rootValue) ? rootValue : rootValue.replace(/[\\/]$/u, "");
  const requested = selection(metadata.selection);
  const input = record(raw);
  const entries = Object.entries(input);
  if (!entries.length || entries.length > LIMITS.modules) throw new Error("model module bound exceeded");
  let paths = 0;
  let bytes = 0;
  const list = (value) => {
    if (!Array.isArray(value) || paths + value.length > LIMITS.paths) throw new Error("model path bound exceeded");
    paths += value.length;
    return [...new Set(value.map((item) => {
      const result = absolutePath(item);
      bytes += Buffer.byteLength(JSON.stringify(result));
      if (bytes > LIMITS.bytes) throw new Error("model byte bound exceeded");
      return result;
    }))];
  };
  const modules = entries.map(([id, rawModule]) => {
    const item = record(rawModule);
    const allowed = ["directory", "variant", "sources", "generatedSources", "bootClasspath", "compileClasspath", "sourceAttachments", "projectDependencies", "javaSourceTarget", "unresolvedCount"];
    if (Object.keys(item).some((key) => !allowed.includes(key))) throw new Error("unknown model field");
    if (typeof item.variant !== "string" || item.unresolvedCount !== 0) throw new Error("incomplete model dependencies");
    const chosen = selection({ module: id, variant: item.variant });
    const directory = absolutePath(item.directory);
    const normalized = directory.replaceAll("\\", "/"), normalizedRoot = root.replaceAll("\\", "/").replace(/\/$/u, "");
    if (normalized !== normalizedRoot && !normalized.startsWith(`${normalizedRoot}/`)) throw new Error("module outside build root");
    const projectDependencies = (item.projectDependencies ?? []).map((dependency) => {
      const value = typeof dependency === "string" ? { module: dependency, variant: item.variant } : record(dependency);
      if (typeof value.module !== "string" || !MODULE.test(value.module) || typeof value.variant !== "string" || !VARIANT.test(value.variant)) throw new Error("invalid project dependency");
      return { module: value.module, variant: value.variant };
    });
    const attachments = (item.sourceAttachments ?? []).map((attachment) => {
      const value = record(attachment);
      return { binary: absolutePath(value.binary), sources: list(value.sources) };
    });
    if (item.javaSourceTarget !== void 0 && item.javaSourceTarget !== null && (typeof item.javaSourceTarget !== "string" || item.javaSourceTarget.length > 32)) throw new Error("invalid Java target");
    return { ...chosen, directory, sources: list(item.sources), generatedSources: list(item.generatedSources ?? []), bootClasspath: list(item.bootClasspath), compileClasspath: list(item.compileClasspath), sourceAttachments: attachments, projectDependencies, javaSourceTarget: item.javaSourceTarget ?? null };
  });
  const ids = new Set(modules.map((module) => module.module));
  if (!modules.some((module) => module.module === requested.module && module.variant === requested.variant) || modules.some((module) => module.projectDependencies.some((dependency) => !ids.has(dependency.module)))) throw new Error("model selection or dependency module missing");
  return Object.freeze({ schemaVersion: 1, origin: "agp-v2", buildRoot: root, gradleVersion: version(metadata.gradleVersion), agpVersion: version(metadata.agpVersion), selection: requested, modules: Object.freeze(modules) });
}

// server-programs/model-diagnostics.mjs
var CLASS = /^[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*$/u;
var CODES = /* @__PURE__ */ new Set(["android-sdk-missing", "repository-credentials-missing", "dependency-unavailable", "dependency-tls", "dependency-dns", "gradle-model-incompatible", "gradle-version-incompatible", "gradle-toolchain-incompatible", "project-configuration-failed", "project-script-failed", "model-selection-unavailable", "model-artifact-missing", "model-path-missing", "program-failed", "program-timeout", "cancelled", "output-bound", "model-invalid", "model-json-invalid", "request-schema", "unsupported-run-configuration", "model-unavailable"]);
function modelFailureCode(error) {
  if (CODES.has(error?.failureCode)) return error.failureCode;
  if (CODES.has(error?.message)) return error.message;
  const chain = String(error?.causeChain ?? "");
  if (/SSLHandshakeException|SSLPeerUnverifiedException|CertPathBuilderException/u.test(chain)) return "dependency-tls";
  if (/UnknownHostException/u.test(chain)) return "dependency-dns";
  if (/ModuleVersionNotFoundException|ModuleVersionResolveException|ArtifactResolveException/u.test(chain)) return "dependency-unavailable";
  if (/UnsupportedMethodException|UnknownModelException/u.test(chain)) return "gradle-model-incompatible";
  if (/ProjectConfigurationException|GradleScriptException/u.test(chain)) return "project-configuration-failed";
  return "model-unavailable";
}
function createModelDiagnosticReader() {
  let partial = "", classes = [], failureCode, sourceFile, sourceLine;
  const line = (value) => {
    const failure = /^MODEL_FAILURE (.+)$/u.exec(value);
    if (failure) {
      const parts = failure[1].split(" ");
      if (parts.length <= 8 && parts.every((v) => v.length <= 160 && CLASS.test(v))) classes = parts;
    }
    const code = /^MODEL_CODE ([a-z][a-z0-9.-]{0,79})$/u.exec(value);
    if (code && CODES.has(code[1])) failureCode = code[1];
    const location = /^MODEL_LOCATION ([A-Za-z0-9._-]{1,80}\.gradle(?:\.kts)?):(\d{1,7})$/u.exec(value);
    if (location && Number(location[2]) > 0 && Number(location[2]) <= 1e6) {
      sourceFile = location[1];
      sourceLine = Number(location[2]);
    }
  };
  return { feed(chunk) {
    for (const char of String(chunk)) {
      if (char === "\n") {
        line(partial.replace(/\r$/u, ""));
        partial = "";
      } else if (partial.length < 2048) partial += char;
      else partial = "invalid";
    }
  }, snapshot() {
    return { causeChain: classes.length ? classes.join(">") : void 0, causeClass: classes.at(-1), failureCode, sourceFile, sourceLine };
  } };
}
function modelFailureRecord(error, started2, debug = false) {
  const record2 = { stage: "error", count: 0, durationMs: Math.round(performance.now() - started2), errorCode: modelFailureCode(error) };
  const classes = String(error?.causeChain ?? "").split(">").filter((value) => value.length <= 160 && CLASS.test(value));
  if (classes.length) record2.causeClass = classes.at(-1);
  if (debug) {
    if (classes.length) record2.causeChain = [classes[0], ...classes.length > 1 ? [classes.at(-1)] : []].join(">").slice(0, 160);
    if (/^[A-Za-z0-9._-]{1,80}\.gradle(?:\.kts)?$/u.test(error?.sourceFile ?? "")) {
      record2.sourceFile = error.sourceFile;
      record2.sourceLine = error.sourceLine;
    }
  }
  if (Buffer.byteLength(JSON.stringify(record2)) > 480) {
    delete record2.causeChain;
    delete record2.sourceFile;
    delete record2.sourceLine;
  }
  return record2;
}

// server-programs/model-environment.mjs
function availableRepositoryEnvironment(environment) {
  const result = {};
  for (const [destination, candidates] of [["ASTERLYN_NEXUS_USERNAME", ["NEXUS_USER", "NEXUS_USERNAME"]], ["ASTERLYN_NEXUS_PASSWORD", ["NEXUS_PASSWORD"]]]) {
    if (Object.hasOwn(environment, destination)) continue;
    const value = candidates.map((key) => environment[key]).find((value2) => typeof value2 === "string" && value2.length > 0);
    if (value !== void 0) result[destination] = value;
  }
  return result;
}

// server-programs/model-selection.mjs
function requestedModelSelection(configuration) {
  if (configuration === void 0 || configuration === null || configuration === "") return { module: "", variant: "" };
  if (typeof configuration !== "string") throw Error("unsupported-run-configuration");
  const match = /^android-run::(?:(.+):)?install([A-Za-z0-9][A-Za-z0-9_.-]{0,159})$/u.exec(configuration);
  if (!match) throw Error("unsupported-run-configuration");
  return { module: !match[1] ? ":" : `:${match[1].replace(/\./gu, ":")}`, variant: `${match[2][0].toLowerCase()}${match[2].slice(1)}` };
}

// server-programs/model.mjs
var MAX_INPUT = 64 * 1024;
var MODEL_SOURCE = fileURLToPath(new URL("../tools/agp-model/AgpModelProgram.java", import.meta.url));
var absolute = (value) => typeof value === "string" && path.isAbsolute(value) && !value.includes("\0");
var debugTrace = false;
var fail = (started2, error) => {
  process.stderr.write(`${JSON.stringify(modelFailureRecord(error, started2, debugTrace))}
`);
  process.exitCode = 1;
};
var activeRun = null;
var cancellationRequested = false;
var ownedDescendants = (rootPid) => {
  if (process.platform === "win32") return [rootPid];
  const result = spawnSync("/bin/ps", ["-axo", "pid=,ppid="], {
    encoding: "utf8",
    timeout: 500,
    maxBuffer: 1024 * 1024,
    stdio: ["ignore", "pipe", "ignore"]
  });
  if (result.error || result.status !== 0) return [rootPid];
  const children = /* @__PURE__ */ new Map();
  for (const line of result.stdout.split("\n")) {
    const match = /^\s*(\d+)\s+(\d+)\s*$/u.exec(line);
    if (!match) continue;
    const pid = Number(match[1]);
    const ppid = Number(match[2]);
    if (!Number.isSafeInteger(pid) || !Number.isSafeInteger(ppid)) continue;
    const list = children.get(ppid) ?? [];
    if (list.length < 128) list.push(pid);
    children.set(ppid, list);
  }
  const owned = [rootPid];
  const queue = [[rootPid, 0]];
  while (queue.length && owned.length < 128) {
    const [parent, depth] = queue.shift();
    if (depth >= 16) continue;
    for (const child of children.get(parent) ?? []) {
      if (owned.includes(child)) continue;
      owned.push(child);
      queue.push([child, depth + 1]);
      if (owned.length >= 128) break;
    }
  }
  return owned;
};
var signalPids = (pids, signal) => {
  for (const pid of pids) {
    try {
      process.kill(pid, signal);
    } catch {
    }
  }
};
var signalChildTree = (child, signal) => {
  if (!child?.pid) return;
  try {
    if (process.platform === "win32") {
      const root = process.env.SystemRoot ?? "C:\\Windows";
      spawnSync(`${root}\\System32\\taskkill.exe`, ["/PID", String(child.pid), "/T", "/F"], { stdio: "ignore", windowsHide: true, timeout: 500 });
    } else {
      signalPids(ownedDescendants(child.pid), signal);
    }
  } catch {
    try {
      child.kill(signal);
    } catch {
    }
  }
};
var stopActiveChild = () => {
  activeRun?.terminate("cancelled");
};
process.on("SIGTERM", () => {
  cancellationRequested = true;
  stopActiveChild();
});
var run = (program, args, { cwd, timeoutMs }) => new Promise((resolve, reject) => {
  const child = spawn(program, args, { cwd, detached: false, stdio: ["ignore", "pipe", "pipe"] });
  let forceTimer = null;
  let terminated = false;
  let ownedPids = null;
  const terminate = (reason) => {
    if (terminated) return;
    terminated = true;
    if (reason) abortReason = new Error(reason);
    ownedPids = ownedDescendants(child.pid);
    if (process.platform === "win32") signalChildTree(child, "SIGTERM");
    else signalPids(ownedPids, "SIGTERM");
    forceTimer = setTimeout(() => {
      if (process.platform === "win32") signalChildTree(child, "SIGKILL");
      else signalPids(ownedPids ?? [child.pid], "SIGKILL");
    }, 5e3);
    forceTimer.unref?.();
  };
  activeRun = { child, terminate };
  let output = "";
  let settled = false;
  let timer;
  let abortReason = null;
  child.stdout.on("data", (chunk) => {
    output += chunk.toString("utf8");
    if (Buffer.byteLength(output) > 16 * 1024 * 1024 && !abortReason) terminate("output-bound");
  });
  const diagnostic = createModelDiagnosticReader();
  child.stderr.on("data", (chunk) => diagnostic.feed(chunk));
  const finish = (error, code) => {
    if (settled) return;
    settled = true;
    if (activeRun?.child === child) activeRun = null;
    clearTimeout(timer);
    clearTimeout(forceTimer);
    forceTimer = null;
    const failure = error ?? abortReason ?? (cancellationRequested ? new Error("cancelled") : code !== 0 ? new Error("program-failed") : null);
    if (failure) {
      Object.assign(failure, diagnostic.snapshot());
      reject(failure);
    } else resolve(output);
  };
  child.once("error", (error) => finish(error));
  child.once("close", (code) => finish(null, code));
  timer = setTimeout(() => terminate("program-timeout"), timeoutMs);
});
var readRequest = async () => {
  let input = "";
  for await (const chunk of process.stdin) {
    input += chunk;
    if (Buffer.byteLength(input) > MAX_INPUT) throw new Error("request-bound");
  }
  const value = JSON.parse(input);
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("request-object");
  if (value.protocolVersion !== 1 || !absolute(value.workspaceRoot) || typeof value.inputDigest !== "string" || value.inputDigest.length > 256) throw new Error("request-schema");
  const tools = value.tools, components = value.components, state = value.state;
  if (!tools?.gradleJava || !absolute(tools.gradleJava.home) || !absolute(tools.gradleJava.java) || !absolute(tools.gradleJava.javac) || !Number.isSafeInteger(tools.gradleJava.major) || tools.gradleJava.major < 17 || tools.gradleJava.major > 24 || typeof tools.gradleJava.digest !== "string" || !state || typeof state !== "object" || Array.isArray(state)) throw new Error("request-fields");
  if (!components || typeof components !== "object" || Array.isArray(components) || Object.keys(components).length > 16 || Object.entries(components).some(([id, component]) => !/^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/u.test(id) || !component || typeof component !== "object" || typeof component.digest !== "string")) throw new Error("component-fields");
  return { ...value, ...requestedModelSelection(state.runConfiguration) };
};
var versionFrom = (names, pattern) => {
  const name = names.find((entry) => pattern.test(entry));
  const match = name && pattern.exec(name);
  if (!match) throw new Error("tool-version-missing");
  return match[1];
};
var wrapperVersion = async (workspace) => {
  const text = await readFile(path.join(workspace, "gradle/wrapper/gradle-wrapper.properties"), "utf8").catch(() => "");
  const match = /gradle-([0-9]+\.[0-9]+(?:\.[0-9]+)?)(?:-[^/]+)?\.(?:zip|tar)/u.exec(text);
  if (!match) throw new Error("gradle-wrapper-version-missing");
  return match[1];
};
var existing = async (file, directory = false) => {
  const value = await stat(file).catch(() => null);
  if (!value || (directory ? !value.isDirectory() : !value.isFile())) throw new Error("model-path-missing");
};
var stablePath = async (file) => {
  const resolved = await realpath(file).catch(() => null);
  if (!resolved) throw new Error("model-path-missing");
  return resolved;
};
var stabilizeModelPaths = async (model) => {
  for (const module of model.modules) {
    module.directory = await stablePath(module.directory);
    module.sources = await Promise.all(module.sources.map(stablePath));
    module.generatedSources = await Promise.all(module.generatedSources.map(stablePath));
    module.bootClasspath = await Promise.all(module.bootClasspath.map(stablePath));
    module.compileClasspath = await Promise.all(module.compileClasspath.map(stablePath));
    module.sourceAttachments = await Promise.all(module.sourceAttachments.map(async (attachment) => ({ binary: await stablePath(attachment.binary), sources: await Promise.all(attachment.sources.map(stablePath)) })));
  }
  return model;
};
var componentJars = async () => {
  const root = fileURLToPath(new URL("./components", import.meta.url));
  const entries = await readdir(root, { withFileTypes: true });
  return entries.filter((entry) => entry.isFile() && entry.name.endsWith(".jar")).map((entry) => path.join(root, entry.name));
};
var prepareGradleHome = async (workspace) => {
  const home = await mkdtemp(path.join(tmpdir(), "asterlyn-android-gradle-home-"));
  const user = process.env.HOME ? path.join(process.env.HOME, ".gradle") : null;
  for (const relative of ["caches", "wrapper/dists"]) {
    if (!user) continue;
    const source = path.join(user, relative);
    const target = path.join(home, relative);
    if (await stat(source).catch(() => null)) {
      await mkdir(path.dirname(target), { recursive: true });
      await symlink(source, target, process.platform === "win32" ? "junction" : "dir").catch(() => {
      });
    }
  }
  const credentials = [];
  for (const file of [path.join(workspace, "local.properties"), ...user ? [path.join(user, "gradle.properties")] : []]) {
    const text = await readFile(file, "utf8").catch(() => "");
    for (const line of text.split(/\r?\n/u)) {
      const match = /^\s*(nexusUsername|nexusPassword|mavenUsername|mavenPassword)\s*=\s*(.*?)\s*$/u.exec(line);
      if (match) credentials.push([match[1], match[2]]);
    }
  }
  for (const [key, value] of credentials) process.env[key.toLowerCase().includes("user") ? "ASTERLYN_NEXUS_USERNAME" : "ASTERLYN_NEXUS_PASSWORD"] = value;
  Object.assign(process.env, availableRepositoryEnvironment(process.env));
  return home;
};
var started = performance.now();
var scratch;
var ownedGradleHome;
try {
  const request = await readRequest();
  debugTrace = request.debugTrace === true;
  request.workspaceRoot = await realpath(request.workspaceRoot);
  request.tools.gradleJava.home = await realpath(request.tools.gradleJava.home);
  request.tools.gradleJava.java = await realpath(request.tools.gradleJava.java);
  request.tools.gradleJava.javac = await realpath(request.tools.gradleJava.javac);
  const jars = await componentJars();
  const builderModelJar = jars.find((file) => /(?:^|\/)builder-model-[^/]+\.jar$/u.test(file));
  if (!builderModelJar) throw new Error("builder-model-component-missing");
  const gradleVersion = await wrapperVersion(request.workspaceRoot);
  const agpVersion = versionFrom([path.basename(builderModelJar)], /^builder-model-(.+)\.jar$/u);
  scratch = await mkdtemp(path.join(tmpdir(), "asterlyn-android-model-"));
  const javaHome = request.tools.gradleJava.home;
  const java = request.tools.gradleJava.java;
  const javac = request.tools.gradleJava.javac;
  await existing(java);
  await existing(javac);
  await existing(javaHome, true);
  await existing(builderModelJar);
  await existing(request.workspaceRoot, true);
  const componentClasspath = jars.join(path.delimiter);
  if (cancellationRequested) throw new Error("cancelled");
  log("compile", 1, started);
  await run(javac, ["-d", scratch, "-cp", componentClasspath, MODEL_SOURCE], { cwd: request.workspaceRoot, timeoutMs: 3e4 });
  if (cancellationRequested) throw new Error("cancelled");
  log("model", 1, started);
  const gradleHome = ownedGradleHome = await prepareGradleHome(request.workspaceRoot);
  const raw = await run(java, ["-cp", `${scratch}${path.delimiter}${componentClasspath}`, "AgpModelProgram", request.workspaceRoot, gradleHome, javaHome, componentClasspath, request.module, request.variant], { cwd: request.workspaceRoot, timeoutMs: 5 * 6e4 });
  const extracted = JSON.parse(raw);
  if (!extracted.selection || typeof extracted.selection.module !== "string" || typeof extracted.selection.variant !== "string" || request.module && extracted.selection.module !== request.module || request.variant && extracted.selection.variant !== request.variant) throw Error("model-selection-unavailable");
  const model = await stabilizeModelPaths(normalizeAgpV2LanguageModel(extracted.projects, { buildRoot: request.workspaceRoot, gradleVersion, agpVersion, selection: extracted.selection }));
  for (const module of model.modules) {
    await existing(module.directory, true);
    for (const source of module.sources) await existing(source, true);
    for (const source of module.generatedSources) await existing(source, true);
    for (const file of [...module.bootClasspath, ...module.compileClasspath]) await existing(file);
    for (const attachment of module.sourceAttachments) {
      await existing(attachment.binary);
      for (const source of attachment.sources) await existing(source, true);
    }
    if (module.compileClasspath.some((file) => file.startsWith(`${module.directory}${path.sep}`) && file.includes(`${path.sep}build${path.sep}`))) throw new Error("project-output-on-external-classpath");
  }
  log("serialize", model.modules.length, started);
  process.stdout.write(`${JSON.stringify(model)}
`);
} catch (error) {
  fail(started, error);
} finally {
  if (scratch) await rm(scratch, { recursive: true, force: true }).catch(() => {
  });
  if (ownedGradleHome) await rm(ownedGradleHome, { recursive: true, force: true }).catch(() => {
  });
}
function log(stage, count, startedAt) {
  process.stderr.write(`${JSON.stringify({ stage, count, durationMs: Math.round(performance.now() - startedAt) })}
`);
}
