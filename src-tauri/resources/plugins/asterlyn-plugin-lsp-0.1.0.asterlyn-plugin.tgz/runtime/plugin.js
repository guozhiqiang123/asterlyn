// src/plugin.ts
var LSP_PLUGIN_ID = "dev.asterlyn.lsp";
var TYPESCRIPT_LANGUAGE_SERVICE_ID = "typescript-javascript";
var languageService = Object.freeze({
  kind: "language-service",
  id: TYPESCRIPT_LANGUAGE_SERVICE_ID,
  label: "TypeScript / JavaScript",
  serverId: "typescript",
  languageIds: Object.freeze(["typescript", "typescriptreact", "javascript", "javascriptreact"]),
  extensions: Object.freeze([".ts", ".tsx", ".js", ".jsx", ".mts", ".cts", ".mjs", ".cjs"]),
  rootMarkers: Object.freeze(["tsconfig.json", "jsconfig.json", "package.json"])
});
var LSP_PLUGIN_MANIFEST = Object.freeze({
  schemaVersion: 3,
  sdkMajor: 1,
  id: LSP_PLUGIN_ID,
  version: "0.1.0",
  nameKey: "name",
  descriptionKey: "description",
  localization: Object.freeze({
    defaultLocale: "en-US",
    locales: Object.freeze({
      "en-US": Object.freeze({
        name: "TypeScript and JavaScript language services",
        description: "Diagnostics, hover, definition and basic completion for TypeScript and JavaScript files."
      }),
      "zh-CN": Object.freeze({
        name: "TypeScript \u548C JavaScript \u8BED\u8A00\u670D\u52A1",
        description: "\u4E3A TypeScript \u548C JavaScript \u6587\u4EF6\u63D0\u4F9B\u8BCA\u65AD\u3001\u60AC\u505C\u3001\u5B9A\u4E49\u548C\u57FA\u7840\u8865\u5168\u3002"
      })
    })
  }),
  settings: Object.freeze([]),
  capabilities: Object.freeze(["languageServices"]),
  permissions: Object.freeze(["host.language-services.execute"]),
  distribution: Object.freeze({
    repository: "guozhiqiang123/asterlyn-plugin-lsp",
    runtime: Object.freeze({ protocol: 1, entry: "runtime/plugin.js" }),
    hostCompatibility: Object.freeze({ minimum: "0.1.13", maximumExclusive: "0.2.0" }),
    license: Object.freeze({ expression: "MIT", file: "LICENSE" }),
    integrity: Object.freeze({})
  })
});
function matchesLanguageWorkspace(_context) {
  return true;
}
var LSP_PLUGIN = Object.freeze({
  sdkMajor: 1,
  id: LSP_PLUGIN_ID,
  version: LSP_PLUGIN_MANIFEST.version,
  manifest: LSP_PLUGIN_MANIFEST,
  matches: matchesLanguageWorkspace,
  activate: ({ contribute }) => {
    const contribution = contribute(languageService);
    return Object.freeze({ dispose: () => contribution.dispose() });
  }
});
export {
  LSP_PLUGIN,
  LSP_PLUGIN_ID,
  LSP_PLUGIN_MANIFEST,
  TYPESCRIPT_LANGUAGE_SERVICE_ID,
  matchesLanguageWorkspace
};
