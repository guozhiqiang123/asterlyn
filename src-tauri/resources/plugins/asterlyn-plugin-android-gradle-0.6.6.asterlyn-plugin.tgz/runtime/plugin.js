var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/deployment-recovery.ts
var deployment_recovery_exports = {};
__export(deployment_recovery_exports, {
  buildUpdateIncompatibleRecovery: () => buildUpdateIncompatibleRecovery,
  isUpdateIncompatibleDeployment: () => isUpdateIncompatibleDeployment
});
function buildUpdateIncompatibleRecovery(deployment, targetId, applicationId) {
  if (!isUpdateIncompatibleDeployment(deployment)) return null;
  return {
    confirmation: {
      titleKey: "run.recovery.uninstall.title",
      messageKey: "run.recovery.uninstall.message",
      confirmLabelKey: "run.recovery.uninstall.confirm",
      cancelLabelKey: "run.recovery.uninstall.cancel",
      destructive: true
    },
    operation: {
      operationId: "android.adb.uninstall",
      parameters: { target: targetId, application: applicationId }
    }
  };
}
function isUpdateIncompatibleDeployment(result) {
  if (result.status === "succeeded" || result.truncated) return false;
  return /(?:^|[^A-Za-z0-9_])INSTALL_FAILED_UPDATE_INCOMPATIBLE(?:$|[^A-Za-z0-9_])/u.test(`${result.stdout}
${result.stderr}`);
}
var init_deployment_recovery = __esm({
  "src/deployment-recovery.ts"() {
    "use strict";
  }
});

// src/detector.ts
var ANDROID_GRADLE_DETECTOR_LIMITS = Object.freeze({
  // Matches the host-owned project catalog ceiling; the detector never expands it.
  maxPaths: 1e5,
  maxPathLength: 4096
});
var SETTINGS = /* @__PURE__ */ new Set(["settings.gradle", "settings.gradle.kts"]);
var BUILDS = /* @__PURE__ */ new Set(["build.gradle", "build.gradle.kts"]);
var WRAPPERS = /* @__PURE__ */ new Set(["gradlew", "gradlew.bat"]);
function detectAndroidGradleEvidence(input) {
  const platform = input.platform ?? "posix";
  if (input.files.length > ANDROID_GRADLE_DETECTOR_LIMITS.maxPaths) {
    return emptySnapshot(input.workspaceRoot, input.generation, platform, false, input.catalogTruncated === true);
  }
  const paths = input.files.map((file) => normalizeWorkspacePath(file.workspacePath, platform)).filter((path) => path !== null);
  const unique = [...new Set(paths)].sort(comparePaths);
  const rootNames = new Set(unique.filter((path) => !path.includes("/")));
  const expectedWrapper = platform === "windows" ? "gradlew.bat" : "gradlew";
  const wrapper = rootNames.has(expectedWrapper) ? expectedWrapper : null;
  const rootSettings = [...rootNames].some((name) => SETTINGS.has(name));
  const rootBuild = [...rootNames].some((name) => BUILDS.has(name));
  const wrapperProperties = unique.includes("gradle/wrapper/gradle-wrapper.properties");
  const gradle = rootSettings || rootBuild || wrapper !== null || wrapperProperties;
  const androidManifest = unique.some((path) => isAndroidManifest(path, platform));
  const android = gradle && androidManifest;
  return Object.freeze({
    kind: "android-gradle-evidence",
    workspaceRoot: input.workspaceRoot,
    generation: input.generation,
    platform,
    bounded: true,
    catalogTruncated: input.catalogTruncated === true,
    gradle,
    android,
    wrapper,
    evidence: Object.freeze(unique.filter((path) => isEvidencePath(path, platform)))
  });
}
function isRunnableGradleWorkspace(evidence) {
  const expectedWrapper = evidence.platform === "windows" ? "gradlew.bat" : "gradlew";
  return evidence.bounded && !evidence.catalogTruncated && evidence.gradle && evidence.wrapper === expectedWrapper;
}
function emptySnapshot(workspaceRoot, generation, platform, bounded, catalogTruncated) {
  return Object.freeze({
    kind: "android-gradle-evidence",
    workspaceRoot,
    generation,
    platform,
    bounded,
    catalogTruncated,
    gradle: false,
    android: false,
    wrapper: null,
    evidence: Object.freeze([])
  });
}
function normalizeWorkspacePath(value, platform) {
  if (typeof value !== "string" || value.length === 0 || value.length > ANDROID_GRADLE_DETECTOR_LIMITS.maxPathLength || value.includes("\0")) return null;
  const slash = platform === "windows" ? value.replaceAll("\\", "/") : value;
  if (slash.startsWith("/") || /^[A-Za-z]:\//.test(slash) || slash.startsWith("//")) return null;
  const segments = slash.split("/");
  if (segments.some((segment) => segment.length === 0 || segment === "." || segment === "..")) return null;
  const normalized = segments.join("/");
  return platform === "windows" ? normalized.toLowerCase() : normalized;
}
function isAndroidManifest(path, platform) {
  const segments = path.split("/");
  const manifest = platform === "windows" ? segments.at(-1)?.toLowerCase() : segments.at(-1);
  return segments.length >= 3 && segments.at(-3) === "src" && segments.at(-2) === "main" && manifest === (platform === "windows" ? "androidmanifest.xml" : "AndroidManifest.xml");
}
function isEvidencePath(path, platform) {
  return !path.includes("/") && (SETTINGS.has(path) || BUILDS.has(path) || WRAPPERS.has(path)) || path === "gradle/wrapper/gradle-wrapper.properties" || isAndroidManifest(path, platform);
}
function comparePaths(left, right) {
  return left < right ? -1 : left > right ? 1 : 0;
}

// src/runtime-codecs.ts
function decodeNativeGradleTasks(value) {
  const decoder = new TextDecoder("utf-8", { fatal: false });
  return typeof decoder.decodeGradleTasks === "function" ? decoder.decodeGradleTasks(value) : null;
}
function decodeUtf8Lines(value) {
  const decoder = new TextDecoder("utf-8", { fatal: false });
  if (typeof decoder.decodeLines === "function") return decoder.decodeLines(value, { trim: true, stripAnsi: true });
  const text = decoder.decode(value);
  const lines = text.includes("\r") ? text.replaceAll("\r\n", "\n").split("\n") : text.split("\n");
  return lines.map((line) => stripAnsi(line).trim());
}
function stripAnsi(value) {
  return value.includes("\x1B") || value.includes("\x9B") ? value.replace(/[\u001B\u009B]\[[0-?]*[ -/]*[@-~]/gu, "") : value;
}
function decodeBase64Bytes(value) {
  const constructor = Uint8Array;
  if (typeof constructor.fromBase64 === "function") return constructor.fromBase64(value);
  const binary = atob(value);
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}
function encodeBase64Bytes(value) {
  const fast = value.toBase64;
  if (typeof fast === "function") return fast.call(value);
  const chunks = [];
  for (let offset = 0; offset < value.length; offset += 32768) {
    chunks.push(String.fromCharCode(...value.subarray(offset, offset + 32768)));
  }
  return btoa(chunks.join(""));
}

// src/discovery.ts
var ANDROID_GRADLE_DISCOVERY_LIMITS = Object.freeze({
  maxOutputBytes: 2 * 1024 * 1024,
  maxLineLength: 16 * 1024,
  maxTasks: 32768
});
var ANDROID_GRADLE_EXECUTION_FLAGS = Object.freeze([
  "--console=plain",
  "--no-daemon",
  "--no-scan"
]);
var ANDROID_GRADLE_TASK_ARGS = Object.freeze([
  "tasks",
  "--all",
  ...ANDROID_GRADLE_EXECUTION_FLAGS
]);
function buildGradleWrapperRequest(evidence) {
  if (!evidence.gradle) return { supported: false, reason: "unsupported-evidence" };
  if (!evidence.bounded || evidence.catalogTruncated) return { supported: false, reason: "unsupported-evidence" };
  const expected = evidence.platform === "windows" ? "gradlew.bat" : "gradlew";
  if (!evidence.wrapper) return { supported: false, reason: "wrapper-missing" };
  if (evidence.wrapper !== expected) return { supported: false, reason: "platform-mismatch" };
  return {
    supported: true,
    request: {
      pluginId: "dev.asterlyn.android-gradle",
      providerId: "gradle-tasks",
      taskId: "discover",
      label: "Gradle tasks",
      executablePath: expected,
      args: [...ANDROID_GRADLE_TASK_ARGS]
    }
  };
}
function parseGradleTasksOutput(output) {
  const bytes = typeof output === "string" ? new TextEncoder().encode(output) : output;
  if (bytes.byteLength > ANDROID_GRADLE_DISCOVERY_LIMITS.maxOutputBytes) return errorSnapshot("Gradle output exceeded the discovery limit.");
  const native = normalizeNativeSnapshot(decodeNativeGradleTasks(bytes));
  if (native) return native;
  const lines = decodeUtf8Lines(bytes);
  const records = /* @__PURE__ */ new Map();
  let recognizedRecords = 0;
  let group = "Other";
  let projectPath = ":";
  let inTaskGroup = false;
  let malformed = false;
  for (let index = 0; index < lines.length; index += 1) {
    const rawLine = lines[index] ?? "";
    if (rawLine.length > ANDROID_GRADLE_DISCOVERY_LIMITS.maxLineLength) {
      malformed = true;
      break;
    }
    const trimmed = rawLine;
    if (!trimmed) continue;
    if (isDivider(trimmed)) continue;
    if (inTaskGroup) {
      const parsed = parseTaskLine(trimmed);
      if (parsed) {
        const { taskName, description } = parsed;
        const id = taskName.startsWith(":") ? taskName : taskName.includes(":") ? `:${taskName}` : `${projectPath === ":" ? ":" : `${projectPath}:`}${taskName}`;
        const separator = id.lastIndexOf(":");
        const taskProjectPath2 = separator > 0 ? id.slice(0, separator) : ":";
        recognizedRecords += 1;
        if (recognizedRecords > ANDROID_GRADLE_DISCOVERY_LIMITS.maxTasks * 4) return errorSnapshot("Gradle task list exceeded the discovery limit.");
        const existing = records.get(id);
        if (existing) {
          if (!existing.description && description) records.set(id, { ...existing, description });
        } else {
          if (records.size >= ANDROID_GRADLE_DISCOVERY_LIMITS.maxTasks) return errorSnapshot("Gradle task list exceeded the discovery limit.");
          records.set(id, { id, label: id, group, description, projectPath: taskProjectPath2, runnable: false, disabledReason: "Task execution is not enabled yet." });
        }
        continue;
      }
    }
    if (isFailureLine(trimmed)) return errorSnapshot("Gradle task discovery failed.");
    if (trimmed.startsWith("Tasks runnable from root project ")) {
      projectPath = ":";
      inTaskGroup = false;
      continue;
    }
    const projectHeader = projectPathFromHeader(trimmed);
    if (projectHeader) {
      projectPath = projectHeader;
      inTaskGroup = false;
      continue;
    }
    if (isTaskGroupHeading(trimmed) && isDivider(lines[index + 1] ?? "")) {
      inTaskGroup = isTaskGroupHeading(trimmed);
      group = trimmed;
      continue;
    }
  }
  if (malformed) return errorSnapshot("Gradle task output contained an overlong line.");
  if (records.size === 0) return errorSnapshot("Gradle output contained no recognizable tasks.");
  const taskIds = [...records.keys()].sort();
  const tasks = new Array(taskIds.length);
  for (let index = 0; index < taskIds.length; index += 1) {
    tasks[index] = records.get(taskIds[index]);
  }
  return { status: "ready", tasks };
}
function normalizeNativeSnapshot(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const snapshot = value;
  if (snapshot.status !== "ready" && snapshot.status !== "error" || !Array.isArray(snapshot.tasks)) return null;
  return snapshot;
}
function errorSnapshot(error) {
  return { status: "error", tasks: [], error };
}
function isFailureLine(value) {
  return value.startsWith("FAILURE:") || value.startsWith("BUILD FAILED") || value.startsWith("Could not determine");
}
function projectPathFromHeader(value) {
  const prefix = "Tasks runnable from project ";
  if (!value.startsWith(prefix)) return null;
  const quoted = value.slice(prefix.length);
  const quote = quoted[0];
  if (quote !== "'" && quote !== '"' || quoted.length < 3) return null;
  const end = quoted.indexOf(quote, 1);
  if (end <= 1) return null;
  const project = quoted.slice(1, end);
  return project.startsWith(":") ? project : `:${project}`;
}
function isDivider(value) {
  if (value.length < 3) return false;
  for (let index = 0; index < value.length; index += 1) {
    if (value.charCodeAt(index) !== 45) return false;
  }
  return true;
}
function isTaskGroupHeading(value) {
  if (!value.endsWith(" tasks") || !isAsciiLetter(value.charCodeAt(0))) return false;
  for (let index = 0; index < value.length; index += 1) {
    const code = value.charCodeAt(index);
    if (!isAsciiLetter(code) && !isAsciiDigit(code) && code !== 95 && code !== 32 && code !== 45) return false;
  }
  return true;
}
function parseTaskLine(value) {
  let taskNameEnd = 0;
  while (taskNameEnd < value.length) {
    const code = value.charCodeAt(taskNameEnd);
    if (code === 32 || code === 9) break;
    taskNameEnd += 1;
  }
  const taskName = value.slice(0, taskNameEnd);
  if (!isTaskName(taskName)) return null;
  let cursor = taskNameEnd;
  while (cursor < value.length && (value.charCodeAt(cursor) === 32 || value.charCodeAt(cursor) === 9)) cursor += 1;
  if (cursor === value.length) return { taskName };
  if (value.charCodeAt(cursor) !== 45) return null;
  cursor += 1;
  while (cursor < value.length && (value.charCodeAt(cursor) === 32 || value.charCodeAt(cursor) === 9)) cursor += 1;
  const description = value.slice(cursor).trim();
  return description ? { taskName, description } : { taskName };
}
function isTaskName(value) {
  if (!value) return false;
  let index = 0;
  if (value.charCodeAt(0) === 58) {
    index = 1;
    if (index === value.length) return false;
  } else if (!isAsciiLetter(value.charCodeAt(0))) return false;
  let segmentLength = 0;
  for (; index < value.length; index += 1) {
    const code = value.charCodeAt(index);
    if (code === 58) {
      if (segmentLength === 0) return false;
      segmentLength = 0;
    } else if (isAsciiLetter(code) || isAsciiDigit(code) || code === 95 || code === 46 || code === 45) segmentLength += 1;
    else return false;
  }
  return segmentLength > 0;
}
function isAsciiLetter(code) {
  return code >= 65 && code <= 90 || code >= 97 && code <= 122;
}
function isAsciiDigit(code) {
  return code >= 48 && code <= 57;
}

// src/execution.ts
function runnableGradleSnapshot(snapshot) {
  if (snapshot.status !== "ready") return snapshot;
  return { ...snapshot, tasks: snapshot.tasks.map((task) => ({ ...task, runnable: true, disabledReason: void 0, runState: "idle" })) };
}
function buildGradleTaskRunPlan(evidence, snapshot, taskId) {
  if (snapshot.status !== "ready" || !taskId || taskId.includes("\0")) return null;
  const task = snapshot.tasks.find((candidate) => candidate.id === taskId && candidate.runnable);
  const wrapper = buildGradleWrapperRequest(evidence);
  if (!task || !wrapper.supported) return null;
  return {
    pluginId: wrapper.request.pluginId,
    providerId: wrapper.request.providerId,
    taskId: task.id,
    label: task.label,
    executablePath: wrapper.request.executablePath,
    args: [task.id, ...ANDROID_GRADLE_EXECUTION_FLAGS]
  };
}
function applyGradleTaskResult(snapshot, taskId, result) {
  if (snapshot.status !== "ready") return snapshot;
  return {
    ...snapshot,
    tasks: snapshot.tasks.map((task) => task.id === taskId ? {
      ...task,
      runnable: true,
      disabledReason: void 0,
      runState: result.status
    } : task)
  };
}
function setGradleTaskRunState(snapshot, taskId, runState) {
  if (snapshot.status !== "ready") return snapshot;
  return {
    ...snapshot,
    tasks: snapshot.tasks.map((task) => ({
      ...task,
      runnable: true,
      disabledReason: void 0,
      runState: task.id === taskId ? runState : "idle"
    }))
  };
}

// src/sdk-compat.ts
var QUICK_KIND = "android.quickAction.kind";
var QUICK_MODULE = "android.quickAction.module";
var QUICK_VARIANT = "android.quickAction.variant";
function withQuickAction(task, quick) {
  return { ...task, metadata: { ...task.metadata ?? {}, [QUICK_KIND]: quick.kind, [QUICK_MODULE]: quick.module, [QUICK_VARIANT]: quick.variant } };
}
function readQuickAction(task) {
  const metadata = task.metadata;
  if (!metadata) return null;
  const kind = metadata[QUICK_KIND];
  const module = metadata[QUICK_MODULE];
  const variant = metadata[QUICK_VARIANT];
  return kind && module && variant && ["assemble", "bundle", "install", "uninstall"].includes(kind) ? { kind, module, variant } : null;
}

// src/quick-actions.ts
var ANDROID_GRADLE_QUICK_ACTION_LIMITS = Object.freeze({
  maxActions: 512,
  maxActionsPerKind: 128,
  maxCandidatesPerSelection: 32
});
var QUICK_ACTION_KINDS = ["assemble", "bundle", "install", "uninstall"];
var QUICK_ACTION_VARIANT_PATTERN = /^[A-Z][A-Za-z0-9_.-]*$/u;
function deriveGradleQuickActions(snapshot) {
  if (snapshot.status !== "ready") return { status: "ready", actions: [], selections: [] };
  const actions = /* @__PURE__ */ new Map();
  const kindCounts = /* @__PURE__ */ new Map();
  for (const task of snapshot.tasks) {
    if (!task.runnable || !task.id || task.id.includes("\0")) continue;
    const parsed = readQuickAction(task) ?? parseTaskId(task.id);
    if (!parsed || !QUICK_ACTION_KINDS.includes(parsed.kind)) continue;
    const id = `${parsed.kind}:${task.id}`;
    if (actions.has(id) || actions.size >= ANDROID_GRADLE_QUICK_ACTION_LIMITS.maxActions || (kindCounts.get(parsed.kind) ?? 0) >= ANDROID_GRADLE_QUICK_ACTION_LIMITS.maxActionsPerKind) continue;
    actions.set(id, { id, taskId: task.id, module: parsed.module, variant: parsed.variant, kind: parsed.kind, label: `${parsed.kind} ${parsed.variant}` });
    kindCounts.set(parsed.kind, (kindCounts.get(parsed.kind) ?? 0) + 1);
  }
  const groupCounts = /* @__PURE__ */ new Map();
  const sorted = [...actions.values()].sort(compareActions).filter((action) => {
    const key = `${action.kind}:${action.variant}`;
    const count = groupCounts.get(key) ?? 0;
    if (count >= ANDROID_GRADLE_QUICK_ACTION_LIMITS.maxCandidatesPerSelection) return false;
    groupCounts.set(key, count + 1);
    return true;
  });
  const grouped = /* @__PURE__ */ new Map();
  for (const action of sorted) {
    const key = `${action.kind}:${action.variant}`;
    const group = grouped.get(key) ?? [];
    group.push(action);
    grouped.set(key, group);
  }
  const selections = [...grouped.entries()].filter(([, candidates]) => candidates.length > 1).map(([id, candidates]) => {
    const [kind, ...variantParts] = id.split(":");
    return { id, kind, variant: variantParts.join(":"), candidates };
  }).sort((a, b) => compareText(a.id, b.id));
  return { status: "ready", actions: sorted, selections };
}
function resolveGradleQuickAction(quickActions, kind, variant, module) {
  const actions = "actions" in quickActions ? quickActions.actions : quickActions;
  const candidates = actions.filter((action) => action.kind === kind && action.variant === variant && (module === void 0 || action.module === module));
  if (candidates.length === 1) return { status: "resolved", action: candidates[0] };
  if (candidates.length > 1) return { status: "ambiguous", candidates };
  return { status: "not-found" };
}
function gradleTaskArtifactHints(taskId) {
  const parsed = parseTaskId(taskId);
  if (!parsed || parsed.kind !== "assemble" && parsed.kind !== "bundle" && parsed.kind !== "install") return [];
  const modulePath = parsed.module === ":" ? "" : `${parsed.module.slice(1).replaceAll(":", "/")}/`;
  return [`${modulePath}build/outputs/${parsed.kind === "bundle" ? "bundle" : "apk"}`];
}
function gradleQuickActionForTaskId(taskId) {
  return parseTaskId(taskId);
}
function withGradleQuickActions(tasks) {
  const projected = [...tasks];
  const kindCounts = /* @__PURE__ */ new Map();
  let actions = 0;
  for (let index = 0; index < projected.length; index += 1) {
    if (actions >= ANDROID_GRADLE_QUICK_ACTION_LIMITS.maxActions) break;
    const task = projected[index];
    if (!task) continue;
    const quick = gradleQuickActionForTaskId(task.id);
    if (!quick) continue;
    const count = kindCounts.get(quick.kind) ?? 0;
    if (count >= ANDROID_GRADLE_QUICK_ACTION_LIMITS.maxActionsPerKind) continue;
    projected[index] = withQuickAction(task, quick);
    kindCounts.set(quick.kind, count + 1);
    actions += 1;
  }
  return projected;
}
function parseTaskId(taskId) {
  if (!taskId.startsWith(":")) return null;
  const lastColon = taskId.lastIndexOf(":");
  const module = lastColon <= 0 ? ":" : taskId.slice(0, lastColon);
  const taskName = taskId.slice(lastColon + 1);
  let kind;
  let prefixLength;
  switch (taskName[0]) {
    case "a":
      if (!taskName.startsWith("assemble")) return null;
      kind = "assemble";
      prefixLength = 8;
      break;
    case "b":
      if (!taskName.startsWith("bundle")) return null;
      kind = "bundle";
      prefixLength = 6;
      break;
    case "i":
      if (!taskName.startsWith("install")) return null;
      kind = "install";
      prefixLength = 7;
      break;
    case "u":
      if (!taskName.startsWith("uninstall")) return null;
      kind = "uninstall";
      prefixLength = 9;
      break;
    default:
      return null;
  }
  const variant = taskName.slice(prefixLength);
  if (!QUICK_ACTION_VARIANT_PATTERN.test(variant) || module !== ":" && !/^:(?:[A-Za-z0-9_.-]+(?::[A-Za-z0-9_.-]+)*)$/u.test(module)) return null;
  return { module, kind, variant };
}
function compareActions(left, right) {
  return compareText(left.taskId, right.taskId) || compareText(left.kind, right.kind) || compareText(left.id, right.id);
}
function compareText(left, right) {
  return left < right ? -1 : left > right ? 1 : 0;
}

// src/task-cache.ts
var ANDROID_GRADLE_CACHE_SCHEMA_VERSION = 2;
var ANDROID_GRADLE_CACHE_LIMITS = Object.freeze({ maxTasks: 32768, maxPayloadBytes: 16 * 1024 * 1024 });
function encodeAndroidGradleCachePayload(tasks, pluginId, pluginVersion, providerId) {
  if (tasks.length > ANDROID_GRADLE_CACHE_LIMITS.maxTasks) throw new Error("Android Gradle cache task count exceeds the limit.");
  const groups = [];
  const groupIndexes = /* @__PURE__ */ new Map();
  const compactTasks = [];
  for (const task of tasks) {
    let group = groupIndexes.get(task.group);
    if (group === void 0) {
      group = groups.length;
      groups.push(task.group);
      groupIndexes.set(task.group, group);
    }
    compactTasks.push(task.description === void 0 ? [task.id, group] : [task.id, group, task.description]);
  }
  const payload = {
    schemaVersion: ANDROID_GRADLE_CACHE_SCHEMA_VERSION,
    pluginId,
    pluginVersion,
    providerId,
    parserVersion: 1,
    discoveryProtocolVersion: 1,
    groups,
    tasks: compactTasks
  };
  const text = JSON.stringify(payload);
  const bytes = new TextEncoder().encode(text);
  if (bytes.byteLength > ANDROID_GRADLE_CACHE_LIMITS.maxPayloadBytes) throw new Error("Android Gradle cache payload exceeds the limit.");
  return encodeBase64Bytes(bytes);
}
function decodeAndroidGradleCachePayload(payloadBase64, pluginId, pluginVersion, providerId) {
  if (typeof payloadBase64 !== "string" || payloadBase64.length === 0 || payloadBase64.length > Math.ceil(ANDROID_GRADLE_CACHE_LIMITS.maxPayloadBytes / 3) * 4) return null;
  try {
    const bytes = decodeBase64Bytes(payloadBase64);
    if (bytes.length > ANDROID_GRADLE_CACHE_LIMITS.maxPayloadBytes) return null;
    const source = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
    if (!source || typeof source !== "object" || Array.isArray(source)) return null;
    const record = source;
    if (record.schemaVersion !== ANDROID_GRADLE_CACHE_SCHEMA_VERSION || record.pluginId !== pluginId || record.pluginVersion !== pluginVersion || record.providerId !== providerId || record.parserVersion !== 1 || record.discoveryProtocolVersion !== 1 || !Array.isArray(record.groups) || record.groups.length > ANDROID_GRADLE_CACHE_LIMITS.maxTasks || !Array.isArray(record.tasks) || record.tasks.length > ANDROID_GRADLE_CACHE_LIMITS.maxTasks) return null;
    const groups = [];
    const seenGroups = /* @__PURE__ */ new Set();
    for (const value of record.groups) {
      if (typeof value !== "string" || value.length === 0 || value.length > 256 || value.includes("\0") || seenGroups.has(value)) return null;
      seenGroups.add(value);
      groups.push(value);
    }
    const tasks = [];
    const taskIds = /* @__PURE__ */ new Set();
    for (const value of record.tasks) {
      if (!Array.isArray(value) || value.length !== 2 && value.length !== 3) return null;
      const [id, groupIndex, description] = value;
      if (typeof id !== "string" || !id || id.length > 4096 || id.includes("\0") || !/^:[A-Za-z0-9_.-]+(?::[A-Za-z0-9_.-]+)*$/u.test(id) || !Number.isSafeInteger(groupIndex) || groupIndex < 0 || groupIndex >= groups.length || description !== void 0 && (typeof description !== "string" || description.length > 256 || description.includes("\0")) || taskIds.has(id)) return null;
      taskIds.add(id);
      tasks.push({
        id,
        label: id,
        group: groups[groupIndex],
        projectPath: projectPathForTask(id),
        ...description === void 0 ? {} : { description },
        runnable: false
      });
    }
    return withGradleQuickActions(tasks);
  } catch {
    return null;
  }
}
function fingerprintPaths(files, platform) {
  const paths = files.map((file) => normalizePath(file.workspacePath, platform)).filter((path) => path !== null);
  return [...new Set(paths.filter(isFingerprintCandidate))].sort();
}
function normalizePath(value, platform) {
  if (!value || value.length > 4096 || value.includes("\0")) return null;
  const path = platform === "windows" ? value.replaceAll("\\", "/").toLowerCase() : value;
  if (path.startsWith("/") || /^[a-z]:\//u.test(path) || path.startsWith("//")) return null;
  const parts = path.split("/");
  if (parts.some((part) => !part || part === "." || part === "..")) return null;
  return parts.join("/");
}
function isFingerprintCandidate(path) {
  if (isGeneratedProjectPath(path)) return false;
  const base = path.slice(path.lastIndexOf("/") + 1);
  if (["build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts", "gradle.properties", "gradlew", "gradlew.bat", "AndroidManifest.xml", "androidmanifest.xml", "gradle-wrapper.properties", "libs.versions.toml"].includes(base)) return true;
  if (path.startsWith("gradle/") && base.endsWith(".toml")) return true;
  return path.startsWith("gradle/wrapper/") && base === "gradle-wrapper.properties" || (path.startsWith("buildSrc/") || path.startsWith("buildsrc/") || path.startsWith("build-logic/")) && (/\.(gradle|gradle\.kts|toml|properties|kt|kts|java)$/u.test(base) || /version/i.test(base));
}
function isGeneratedProjectPath(path) {
  return path.split("/").some((segment) => segment === "build" || segment === ".gradle" || segment === "out");
}
function intersectsFingerprintPaths(candidates, changed, platform) {
  const set = new Set(candidates);
  return changed.some((path) => {
    const normalized = normalizePath(path, platform);
    return normalized !== null && (set.has(normalized) || isFingerprintCandidate(normalized));
  });
}
function projectPathForTask(taskId) {
  const segments = taskId.slice(1).split(":");
  return segments.length <= 1 ? ":" : `:${segments.slice(0, -1).join(":")}`;
}

// src/collection.ts
var ANDROID_GRADLE_COLLECTION_PROVIDER_ID = "gradle-tasks";
function buildAndroidGradleTaskCollection(snapshot) {
  const projects = /* @__PURE__ */ new Map();
  for (const task of snapshot.tasks) {
    const projectPath = taskProjectPath(task.id, task.projectPath);
    let project = projects.get(projectPath);
    if (!project) {
      project = { projectPath, groups: /* @__PURE__ */ new Map() };
      projects.set(projectPath, project);
    }
    const group = task.group.trim() || "Other";
    project.groups.set(group, [...project.groups.get(group) ?? [], task]);
  }
  const nodes = [];
  const orderedProjects = [...projects.values()].sort(compareProjects);
  orderedProjects.forEach((project, projectIndex) => {
    const projectId = project.projectPath === ":" ? "project.root" : stableId("project", project.projectPath);
    if (project.projectPath !== ":") {
      nodes.push({
        id: projectId,
        parentId: null,
        label: project.projectPath.slice(1) || project.projectPath,
        kind: "group",
        order: projectIndex * 1e5,
        metadata: { "android.gradle.nodeKind": "module", "android.gradle.projectPath": project.projectPath }
      });
    }
    [...project.groups.entries()].sort(([left], [right]) => compareText2(left, right)).forEach(([group, tasks], groupIndex) => {
      const groupId = `${projectId}.${stableId("group", group)}`;
      nodes.push({
        id: groupId,
        parentId: project.projectPath === ":" ? null : projectId,
        label: groupLabel(group),
        kind: "group",
        order: project.projectPath === ":" ? projectIndex * 1e5 + groupIndex : groupIndex,
        metadata: { "android.gradle.nodeKind": "group", "android.gradle.group": group }
      });
      [...tasks].sort((left, right) => compareText2(left.id, right.id)).forEach((task, taskIndex) => {
        nodes.push({
          id: `${groupId}.${stableId("task", task.id)}`,
          parentId: groupId,
          label: task.id,
          kind: "task",
          order: taskIndex,
          taskId: task.id,
          metadata: { "android.gradle.projectPath": project.projectPath, "android.gradle.group": group }
        });
      });
    });
  });
  return { providerId: ANDROID_GRADLE_COLLECTION_PROVIDER_ID, nodes, truncated: false };
}
function taskProjectPath(taskId, explicit) {
  if (explicit && /^:(?:[A-Za-z0-9_.-]+(?::[A-Za-z0-9_.-]+)*)?$/u.test(explicit)) return explicit;
  if (!taskId.startsWith(":")) return ":";
  const separator = taskId.lastIndexOf(":");
  return separator > 0 ? taskId.slice(0, separator) : ":";
}
function groupLabel(group) {
  const trimmed = group.replace(/\s+tasks$/iu, "").trim() || group.trim() || "Other";
  return trimmed.charAt(0).toLocaleLowerCase() + trimmed.slice(1);
}
function stableId(kind, value) {
  let hash = 0xcbf29ce484222325n;
  for (const byte of new TextEncoder().encode(value)) {
    hash ^= BigInt(byte);
    hash = BigInt.asUintN(64, hash * 0x100000001b3n);
  }
  return `${kind}.${hash.toString(16).padStart(16, "0")}`;
}
function compareProjects(left, right) {
  if (left.projectPath === ":" && right.projectPath !== ":") return -1;
  if (right.projectPath === ":" && left.projectPath !== ":") return 1;
  return compareText2(left.projectPath, right.projectPath);
}
function compareText2(left, right) {
  return left.localeCompare(right, void 0, { numeric: true, sensitivity: "base" });
}

// manifest.json
var manifest_default = {
  schemaVersion: 3,
  sdkMajor: 1,
  id: "dev.asterlyn.android-gradle",
  version: "0.6.6",
  nameKey: "name",
  descriptionKey: "description",
  localization: {
    defaultLocale: "en-US",
    locales: {
      "en-US": {
        name: "Android",
        description: "Android development tools for building, running, and inspecting devices.",
        "panel.run": "Run",
        "panel.tasks": "Tasks",
        "device.status.online": "Online",
        "device.status.offline": "Offline",
        "device.status.unauthorized": "Unauthorized",
        "device.status.unknown": "Unknown",
        "device.error.discovery": "Unable to discover Android devices.",
        "device.error.adbUnavailable": "ADB is unavailable.",
        "device.action.refresh": "Refresh devices",
        "device.action.retry": "Retry",
        "device.title": "Android devices",
        "device.loading": "Discovering Android devices\u2026",
        "device.empty": "No Android devices found.",
        "device.emptyDetail": "Connect a device or start an emulator, then refresh.",
        "device.count": "{count} detected",
        "run.empty": "No Android run configuration is available.",
        "run.loading": "Resolving Android run configuration\u2026",
        "run.error": "Android run configuration failed.",
        "run.configuration.select": "Run configuration",
        "run.target.select": "Target device",
        "run.action.start": "Run",
        "run.action.stop": "Stop",
        "run.configuration.androidApp": "Android app",
        "run.configuration.incomplete": "Run is unavailable until the plugin can authoritatively resolve the application ID and launcher activity.",
        "run.session.running": "Running Android application\u2026",
        "run.session.succeeded": "Android application launched.",
        "run.session.failed": "Android application Run failed.",
        "run.session.cancelled": "Android application Run was cancelled.",
        "run.session.crashed": "Android application Run crashed.",
        "run.phase.building": "Building application\u2026",
        "run.phase.resolving-artifact": "Resolving built APK\u2026",
        "run.phase.validating-target": "Validating selected device\u2026",
        "run.phase.installing": "Installing on selected device\u2026",
        "run.phase.awaiting-deployment-recovery": "Waiting for permission to replace the existing app\u2026",
        "run.phase.recovering-deployment": "Removing the incompatible existing app\u2026",
        "run.phase.launching": "Launching application\u2026",
        "run.recovery.uninstall.title": "Replace the existing application?",
        "run.recovery.uninstall.message": "The installed app has a different signature. It must be uninstalled before continuing. Uninstalling deletes its local data.",
        "run.recovery.uninstall.confirm": "Uninstall and continue",
        "run.recovery.uninstall.cancel": "Keep existing app",
        "settings.taskPresentation.label": "Task presentation",
        "settings.taskPresentation.description": "Choose the task tree shown in the Tasks tool window.",
        "settings.taskPresentation.allTasksTree": "All tasks tree",
        "settings.taskPresentation.quickActionsTree": "Android quick actions tree",
        "authorization.workspaceTrust.label": "Trust Gradle tasks in this workspace",
        "authorization.workspaceTrust.description": "Allow this plugin to run reviewed Gradle tasks in the current workspace. Turning this off also clears remembered task confirmations.",
        "authorization.rememberTask.label": "Do not ask again for this exact Gradle task",
        "authorization.rememberTask.description": "The approval is limited to this workspace and the current executable and arguments. Changes require confirmation again."
      },
      "zh-CN": {
        name: "Android",
        description: "\u7528\u4E8E\u6784\u5EFA\u3001\u8FD0\u884C\u548C\u67E5\u770B Android \u8BBE\u5907\u7684\u5F00\u53D1\u5DE5\u5177\u3002",
        "panel.run": "\u8FD0\u884C",
        "panel.tasks": "\u4EFB\u52A1",
        "device.status.online": "\u5728\u7EBF",
        "device.status.offline": "\u79BB\u7EBF",
        "device.status.unauthorized": "\u672A\u6388\u6743",
        "device.status.unknown": "\u672A\u77E5",
        "device.error.discovery": "\u65E0\u6CD5\u53D1\u73B0 Android \u8BBE\u5907\u3002",
        "device.error.adbUnavailable": "ADB \u4E0D\u53EF\u7528\u3002",
        "device.action.refresh": "\u5237\u65B0\u8BBE\u5907",
        "device.action.retry": "\u91CD\u8BD5",
        "device.title": "Android \u8BBE\u5907",
        "device.loading": "\u6B63\u5728\u53D1\u73B0 Android \u8BBE\u5907\u2026",
        "device.empty": "\u672A\u53D1\u73B0 Android \u8BBE\u5907\u3002",
        "device.emptyDetail": "\u8BF7\u8FDE\u63A5\u8BBE\u5907\u6216\u542F\u52A8\u6A21\u62DF\u5668\uFF0C\u7136\u540E\u5237\u65B0\u3002",
        "device.count": "\u5DF2\u53D1\u73B0 {count} \u53F0",
        "run.empty": "\u6CA1\u6709\u53EF\u7528\u7684 Android \u8FD0\u884C\u914D\u7F6E\u3002",
        "run.loading": "\u6B63\u5728\u89E3\u6790 Android \u8FD0\u884C\u914D\u7F6E\u2026",
        "run.error": "Android \u8FD0\u884C\u914D\u7F6E\u89E3\u6790\u5931\u8D25\u3002",
        "run.configuration.select": "\u8FD0\u884C\u914D\u7F6E",
        "run.target.select": "\u76EE\u6807\u8BBE\u5907",
        "run.action.start": "\u8FD0\u884C",
        "run.action.stop": "\u505C\u6B62",
        "run.configuration.androidApp": "Android \u5E94\u7528",
        "run.configuration.incomplete": "\u63D2\u4EF6\u5C1A\u672A\u53EF\u9760\u89E3\u6790\u5E94\u7528 ID \u548C\u542F\u52A8 Activity\uFF0C\u56E0\u6B64\u6682\u4E0D\u80FD\u8FD0\u884C\u3002",
        "run.session.running": "\u6B63\u5728\u8FD0\u884C Android \u5E94\u7528\u2026",
        "run.session.succeeded": "Android \u5E94\u7528\u5DF2\u542F\u52A8\u3002",
        "run.session.failed": "Android \u5E94\u7528\u8FD0\u884C\u5931\u8D25\u3002",
        "run.session.cancelled": "Android \u5E94\u7528\u8FD0\u884C\u5DF2\u53D6\u6D88\u3002",
        "run.session.crashed": "Android \u5E94\u7528\u8FD0\u884C\u5F02\u5E38\u7EC8\u6B62\u3002",
        "run.phase.building": "\u6B63\u5728\u6784\u5EFA\u5E94\u7528\u2026",
        "run.phase.resolving-artifact": "\u6B63\u5728\u5B9A\u4F4D\u6784\u5EFA\u751F\u6210\u7684 APK\u2026",
        "run.phase.validating-target": "\u6B63\u5728\u9A8C\u8BC1\u6240\u9009\u8BBE\u5907\u2026",
        "run.phase.installing": "\u6B63\u5728\u5B89\u88C5\u5230\u6240\u9009\u8BBE\u5907\u2026",
        "run.phase.awaiting-deployment-recovery": "\u6B63\u5728\u7B49\u5F85\u786E\u8BA4\u662F\u5426\u66FF\u6362\u5DF2\u6709\u5E94\u7528\u2026",
        "run.phase.recovering-deployment": "\u6B63\u5728\u5378\u8F7D\u7B7E\u540D\u4E0D\u517C\u5BB9\u7684\u5DF2\u6709\u5E94\u7528\u2026",
        "run.phase.launching": "\u6B63\u5728\u542F\u52A8\u5E94\u7528\u2026",
        "run.recovery.uninstall.title": "\u8981\u66FF\u6362\u5DF2\u6709\u5E94\u7528\u5417\uFF1F",
        "run.recovery.uninstall.message": "\u6240\u9009\u8BBE\u5907\u4E0A\u5DF2\u5B89\u88C5\u7684\u540C\u5305\u540D\u5E94\u7528\u4F7F\u7528\u4E86\u4E0D\u540C\u7B7E\u540D\u3002\u7EE7\u7EED\u5B89\u88C5\u524D\u5FC5\u987B\u5148\u5378\u8F7D\u5B83\uFF1B\u5378\u8F7D\u4F1A\u6E05\u9664\u8BE5\u5E94\u7528\u7684\u672C\u5730\u6570\u636E\u3002",
        "run.recovery.uninstall.confirm": "\u5378\u8F7D\u5E76\u7EE7\u7EED",
        "run.recovery.uninstall.cancel": "\u4FDD\u7559\u5DF2\u6709\u5E94\u7528",
        "settings.taskPresentation.label": "\u4EFB\u52A1\u5C55\u793A\u65B9\u5F0F",
        "settings.taskPresentation.description": "\u9009\u62E9\u4EFB\u52A1\u7A97\u53E3\u4E2D\u663E\u793A\u7684\u4EFB\u52A1\u6811\u3002",
        "settings.taskPresentation.allTasksTree": "\u5B8C\u6574\u4EFB\u52A1\u6811",
        "settings.taskPresentation.quickActionsTree": "Android \u5FEB\u6377\u64CD\u4F5C\u6811",
        "authorization.workspaceTrust.label": "\u4FE1\u4EFB\u6B64\u5DE5\u4F5C\u533A\u4E2D\u7684 Gradle \u4EFB\u52A1",
        "authorization.workspaceTrust.description": "\u5141\u8BB8\u6B64\u63D2\u4EF6\u5728\u5F53\u524D\u5DE5\u4F5C\u533A\u8FD0\u884C\u7ECF\u8FC7\u5BA1\u6838\u7684 Gradle \u4EFB\u52A1\u3002\u5173\u95ED\u540E\u4E5F\u4F1A\u6E05\u9664\u5DF2\u8BB0\u4F4F\u7684\u4EFB\u52A1\u786E\u8BA4\u3002",
        "authorization.rememberTask.label": "\u4E0D\u518D\u8BE2\u95EE\u8FD9\u4E2A\u7CBE\u786E\u7684 Gradle \u4EFB\u52A1",
        "authorization.rememberTask.description": "\u6388\u6743\u4EC5\u9650\u5F53\u524D\u5DE5\u4F5C\u533A\u4EE5\u53CA\u5F53\u524D\u53EF\u6267\u884C\u6587\u4EF6\u548C\u53C2\u6570\uFF1B\u53D1\u751F\u53D8\u5316\u65F6\u4F1A\u91CD\u65B0\u8BE2\u95EE\u3002"
      }
    }
  },
  settings: [
    {
      id: "taskPresentation",
      kind: "enum",
      labelKey: "settings.taskPresentation.label",
      descriptionKey: "settings.taskPresentation.description",
      defaultValue: "all-tasks-tree",
      options: [
        {
          value: "all-tasks-tree",
          labelKey: "settings.taskPresentation.allTasksTree"
        },
        {
          value: "quick-actions-tree",
          labelKey: "settings.taskPresentation.quickActionsTree"
        }
      ]
    }
  ],
  taskAuthorization: {
    workspaceTrust: {
      id: "workspaceTrust",
      labelKey: "authorization.workspaceTrust.label",
      descriptionKey: "authorization.workspaceTrust.description"
    },
    taskConfirmation: {
      rememberLabelKey: "authorization.rememberTask.label",
      rememberDescriptionKey: "authorization.rememberTask.description"
    }
  },
  workspaceTool: {
    id: "android",
    titleKey: "name",
    icon: "device",
    views: [
      {
        id: "run",
        labelKey: "panel.run"
      },
      {
        id: "tasks",
        labelKey: "panel.tasks"
      }
    ],
    defaultView: "tasks"
  },
  hostOperations: [
    {
      id: "adb.devices"
    },
    {
      id: "android.apk.inspect"
    },
    {
      id: "android.adb.install"
    },
    {
      id: "android.adb.uninstall"
    },
    {
      id: "android.adb.launch"
    }
  ],
  capabilities: [
    "workspaceCatalog",
    "tasks",
    "taskCache",
    "taskAuthorization",
    "processQueries",
    "toolOperations",
    "workspaceState",
    "executionTargets",
    "runConfigurations",
    "workspaceModels"
  ],
  permissions: [
    "host.workspace.catalog.read",
    "host.tasks.discover",
    "host.tasks.execute",
    "host.tasks.cache",
    "host.process.query",
    "host.tool.execute",
    "host.workspace.state",
    "host.execution-targets.read",
    "host.workspace-models.execute"
  ],
  modelProviders: [
    {
      id: "android-gradle-model",
      schema: 1,
      program: {
        entry: "server-programs/model.mjs",
        tools: [
          {
            id: "gradleJava",
            kind: "java",
            minimumMajor: 17,
            maximumMajorExclusive: 25
          }
        ],
        components: []
      },
      inputGlobs: [
        "local.properties",
        "gradle.properties",
        "gradle/wrapper/gradle-wrapper.properties",
        "gradle/libs.versions.toml",
        "**/*.gradle",
        "**/*.gradle.kts",
        "**/gradle-wrapper.properties",
        "**/libs.versions.toml"
      ],
      stateBindings: [
        {
          key: "runConfiguration",
          contributionId: "android-run-configurations",
          pointer: "/selectedConfigurationId"
        }
      ]
    }
  ],
  distribution: {
    repository: "guozhiqiang123/asterlyn-plugin-android-gradle",
    runtime: {
      protocol: 1,
      entry: "runtime/plugin.js"
    },
    hostCompatibility: {
      minimum: "0.1.22",
      maximumExclusive: "0.2.0"
    },
    license: {
      expression: "MIT",
      file: "LICENSE"
    },
    integrity: {}
  }
};

// src/manifest.ts
var ANDROID_GRADLE_PLUGIN_MANIFEST = Object.freeze(
  manifest_default
);

// src/devices.ts
var ANDROID_DEVICE_DISCOVERY_LIMITS = Object.freeze({
  maxOutputBytes: 512 * 1024,
  maxLineLength: 8 * 1024,
  maxDevices: 256
});
var STATUS_RANK = {
  online: 0,
  unknown: 1,
  offline: 2,
  unauthorized: 3
};
function parseAndroidDevicesOutput(output) {
  const bytes = typeof output === "string" ? new TextEncoder().encode(output) : output;
  if (bytes.byteLength > ANDROID_DEVICE_DISCOVERY_LIMITS.maxOutputBytes) {
    return errorResult("Android device discovery output exceeded the size limit.");
  }
  const text = new TextDecoder("utf-8", { fatal: false }).decode(bytes);
  const lines = text.split(/\r?\n/u);
  const records = /* @__PURE__ */ new Map();
  let headerFound = false;
  for (const rawLine of lines) {
    if (rawLine.length > ANDROID_DEVICE_DISCOVERY_LIMITS.maxLineLength) {
      return errorResult("Android device discovery output contained an overlong line.");
    }
    const line = rawLine.trim();
    if (!line) continue;
    if (!headerFound) {
      if (line === "List of devices attached") {
        headerFound = true;
        continue;
      }
      if (isDaemonPreamble(line)) continue;
      return errorResult("Android device discovery output was malformed before its header.");
    }
    const parsed = parseDeviceLine(line);
    if (!parsed) return errorResult("Android device discovery output contained a malformed device record.");
    const previous = records.get(parsed.serial);
    if (!previous) {
      if (records.size >= ANDROID_DEVICE_DISCOVERY_LIMITS.maxDevices) {
        return errorResult("Android device discovery returned too many devices.");
      }
      records.set(parsed.serial, parsed);
    } else if (STATUS_RANK[parsed.status] > STATUS_RANK[previous.status]) {
      records.set(parsed.serial, parsed);
    }
  }
  if (!headerFound) return errorResult("Android device discovery output did not contain its header.");
  return { status: "ready", devices: [...records.values()].sort((a, b) => a.serial.localeCompare(b.serial)) };
}
function parseDeviceLine(line) {
  const fields = line.split(/\s+/u);
  const serial = fields.shift();
  const statusToken = fields.shift();
  if (!serial || !statusToken || /\s/u.test(serial)) return null;
  const status = toStatus(statusToken);
  const metadata = {};
  for (const field of fields) {
    const separator = field.indexOf(":");
    if (separator <= 0 || separator === field.length - 1) return null;
    const key = field.slice(0, separator);
    const value = field.slice(separator + 1);
    if (!/^[A-Za-z_][A-Za-z0-9_.-]*$/u.test(key) || !value || value.includes(":") && key === "transport_id") return null;
    metadata[key] = value;
  }
  const emulator = /^emulator-\d+$/u.test(serial) || metadata.type === "emulator";
  const label = metadata.model ?? metadata.device ?? serial;
  const details = Object.entries(metadata).map(([key, value]) => `${key}=${value}`).join(", ");
  return {
    serial,
    label,
    detail: details || statusToken,
    status,
    selectable: status === "online",
    metadata: Object.freeze(metadata),
    emulator
  };
}
function toStatus(value) {
  if (value === "device") return "online";
  if (value === "offline") return "offline";
  if (value === "unauthorized") return "unauthorized";
  return "unknown";
}
function isDaemonPreamble(line) {
  return /^\* daemon (?:not running; starting now at tcp:\d+|started successfully|already running) \*$/u.test(line);
}
function errorResult(error) {
  return { status: "error", devices: [], error };
}

// src/device-provider.ts
var SELECTED_TARGET_KEY = "selectedDevice";
function createAndroidDeviceProvider(context) {
  const listeners = /* @__PURE__ */ new Set();
  let disposed = false;
  let revision = 0;
  let refreshInFlight = null;
  let selectedTargetId = null;
  let snapshot = context.processQueries ? { status: "loading", targets: [], selectedTargetId: null } : { status: "unavailable", targets: [], selectedTargetId: null, error: "ADB discovery is unavailable in this host." };
  const publish = () => {
    if (disposed) return;
    for (const listener of listeners) listener();
  };
  const refreshOnce = async () => {
    if (disposed || !context.processQueries) return;
    const current = ++revision;
    snapshot = { ...snapshot, status: "loading", error: void 0 };
    publish();
    try {
      const result = await context.processQueries.execute("adb.devices");
      if (disposed || current !== revision) return;
      if (result.status !== "succeeded") {
        snapshot = {
          status: result.status === "cancelled" ? "unavailable" : "error",
          targets: [],
          selectedTargetId: null,
          error: result.error ?? (result.stderr.trim() || `ADB device discovery ${result.status}.`)
        };
        publish();
        return;
      }
      if (result.truncated) {
        snapshot = { status: "error", targets: [], selectedTargetId: null, error: "ADB device discovery output was truncated." };
        publish();
        return;
      }
      const parsed = parseAndroidDevicesOutput(result.stdout);
      if (parsed.status === "error") {
        snapshot = { status: "error", targets: [], selectedTargetId: null, error: parsed.error };
        publish();
        return;
      }
      const targets = parsed.devices.map((device) => Object.freeze({
        id: device.serial,
        label: device.label,
        detail: device.detail,
        status: device.status,
        selectable: device.selectable,
        metadata: Object.freeze({ ...device.metadata, serial: device.serial, emulator: String(device.emulator) })
      }));
      if (!targets.some((target) => target.id === selectedTargetId && target.selectable)) {
        selectedTargetId = targets.find((target) => target.status === "online" && target.selectable)?.id ?? null;
      }
      snapshot = { status: "ready", targets: Object.freeze(targets), selectedTargetId };
      publish();
    } catch (error) {
      if (disposed || current !== revision) return;
      snapshot = {
        status: "error",
        targets: [],
        selectedTargetId: null,
        error: error instanceof Error ? error.message : String(error)
      };
      publish();
    }
  };
  const refresh = () => {
    if (refreshInFlight) return refreshInFlight;
    const tracked = refreshOnce().finally(() => {
      if (refreshInFlight === tracked) refreshInFlight = null;
    });
    refreshInFlight = tracked;
    return tracked;
  };
  const contribution = Object.freeze({
    kind: "execution-target-provider",
    id: "android-devices",
    snapshot: () => snapshot,
    subscribe: (listener) => {
      listeners.add(listener);
      return { dispose: () => {
        listeners.delete(listener);
      } };
    },
    refresh,
    select: async (targetId) => {
      if (targetId !== null && !snapshot.targets.some((target) => target.id === targetId && target.selectable)) {
        throw new Error(`Android device is not selectable: ${targetId}`);
      }
      selectedTargetId = targetId;
      snapshot = { ...snapshot, selectedTargetId };
      publish();
      await context.workspaceState?.write(SELECTED_TARGET_KEY, targetId ?? "");
    }
  });
  return {
    contribution,
    start: () => {
      void (async () => {
        try {
          const restored = await context.workspaceState?.read(SELECTED_TARGET_KEY);
          if (!disposed && restored) selectedTargetId = restored;
        } finally {
          if (!disposed) await refresh();
        }
      })();
    },
    dispose: () => {
      disposed = true;
      revision += 1;
      listeners.clear();
    }
  };
}

// src/run-configurations.ts
var ANDROID_RUN_CONFIGURATION_PROVIDER_ID = "android-run-configurations";
var ANDROID_RUN_TARGET_PROVIDER_ID = "android-devices";
function deriveAndroidRunConfigurations(snapshot) {
  const actions = deriveGradleQuickActions(snapshot).actions;
  const builds = new Map(actions.filter((action) => action.kind === "assemble").map((action) => [`${action.module}\0${action.variant}`, action]));
  return actions.filter((action) => action.kind === "install" && !action.variant.endsWith("AndroidTest")).flatMap((install) => {
    const build = builds.get(`${install.module}\0${install.variant}`);
    if (!build) return [];
    const moduleLabel = install.module === ":" ? "root" : install.module.slice(1);
    const id = `android-run:${install.taskId}`;
    return Object.freeze({
      id,
      taskId: build.taskId,
      installTaskId: install.taskId,
      module: install.module,
      variant: install.variant,
      descriptor: Object.freeze({
        id,
        label: `${moduleLabel} \xB7 ${install.variant}`,
        detail: build.taskId,
        status: "ready",
        targetProviderId: ANDROID_RUN_TARGET_PROVIDER_ID,
        metadata: Object.freeze({ module: install.module, variant: install.variant, taskId: build.taskId, installTaskId: install.taskId })
      })
    });
  });
}
function androidRunConfigurationSnapshot(tasks, preferredConfigurationId) {
  if (tasks.status === "unavailable") return { status: "ready", configurations: [], selectedConfigurationId: null };
  if (tasks.status === "error") return { status: "error", configurations: [], selectedConfigurationId: null, error: tasks.error ?? "Gradle task discovery failed." };
  const configurations = deriveAndroidRunConfigurations(tasks.status === "ready" ? tasks : { ...tasks, status: "ready" });
  const selected = configurations.some((configuration) => configuration.id === preferredConfigurationId) ? preferredConfigurationId : configurations[0]?.id ?? null;
  return {
    status: tasks.status,
    configurations: configurations.map((configuration) => tasks.status === "ready" ? configuration.descriptor : { ...configuration.descriptor, status: "incomplete" }),
    selectedConfigurationId: selected
  };
}
function buildAndroidStagedRunPlan(build, targetId, variant, apply) {
  let selectedArtifact = null;
  let buildOutputUsable = false;
  const buildApply = build.apply;
  const supervisedBuild = {
    ...build,
    artifactSearch: {
      hints: build.artifactSearch?.hints ?? [],
      sidecarNames: ["output-metadata.json"]
    },
    apply: (result) => {
      buildOutputUsable = result.status === "succeeded" && !result.truncated;
      buildApply(result);
    }
  };
  return Object.freeze({
    kind: "staged",
    build: supervisedBuild,
    inspect: (artifacts, sidecars, truncated) => {
      if (!buildOutputUsable || truncated) return null;
      selectedArtifact = resolveAgpSingleApkArtifact(artifacts, sidecars, variant);
      return selectedArtifact ? { operationId: "android.apk.inspect", parameters: { artifact: selectedArtifact.workspacePath } } : null;
    },
    deploy: (inspection) => {
      if (!selectedArtifact || inspection.status !== "succeeded" || inspection.truncated) return null;
      return {
        operationId: "android.adb.install",
        parameters: { target: targetId, artifact: selectedArtifact.workspacePath }
      };
    },
    recoverDeployment: async (inspection, deployment) => {
      const launch = parseAndroidLaunchComponent(inspection.stdout);
      if (!launch) return null;
      const { buildUpdateIncompatibleRecovery: buildUpdateIncompatibleRecovery2 } = await Promise.resolve().then(() => (init_deployment_recovery(), deployment_recovery_exports));
      return buildUpdateIncompatibleRecovery2(deployment, targetId, launch.applicationId);
    },
    launch: (inspection) => {
      if (inspection.status !== "succeeded" || inspection.truncated) return null;
      const launch = parseAndroidLaunchComponent(inspection.stdout);
      return launch ? {
        operationId: "android.adb.launch",
        parameters: { target: targetId, component: launch.component }
      } : null;
    },
    apply
  });
}
function resolveAgpSingleApkArtifact(artifacts, sidecars, variant) {
  if (!variant || variant.length > 256 || !/^[A-Za-z0-9_.-]+$/u.test(variant)) return null;
  const agpVariantName = `${variant[0].toLowerCase()}${variant.slice(1)}`;
  const artifactByPath = new Map(
    artifacts.filter((artifact) => artifact.kind === "apk" && artifact.workspacePath.endsWith(".apk")).map((artifact) => [artifact.workspacePath, artifact])
  );
  const matches = [];
  for (const sidecar of sidecars) {
    if (!sidecar.workspacePath.endsWith("/output-metadata.json")) continue;
    const metadata = parseAgpOutputMetadata(decodeBase64Utf8(sidecar.dataBase64));
    if (!metadata || metadata.variantName !== agpVariantName || metadata.outputFile.includes("/") || metadata.outputFile.includes("\\")) continue;
    const directory = sidecar.workspacePath.slice(0, sidecar.workspacePath.lastIndexOf("/") + 1);
    const artifact = artifactByPath.get(`${directory}${metadata.outputFile}`);
    if (artifact) matches.push(artifact);
  }
  return matches.length === 1 ? matches[0] ?? null : null;
}
function parseAgpOutputMetadata(text) {
  if (!text || text.length > 65536) return null;
  try {
    const value = JSON.parse(text);
    if (value.artifactType && (typeof value.artifactType !== "object" || value.artifactType.type !== "APK")) return null;
    if (typeof value.variantName !== "string" || !Array.isArray(value.elements) || value.elements.length !== 1) return null;
    const element = value.elements[0];
    if (!element || typeof element !== "object") return null;
    const record = element;
    if (record.type !== "SINGLE" || typeof record.outputFile !== "string" || !record.outputFile.endsWith(".apk") || record.outputFile.length > 512) return null;
    return Object.freeze({ variantName: value.variantName, outputFile: record.outputFile });
  } catch {
    return null;
  }
}
function parseAndroidLaunchComponent(output) {
  const applicationId = output.match(/^package:\s+name='([^']+)'/mu)?.[1] ?? null;
  const activities = new Set(
    [...output.matchAll(/^(?:launchable-activity|leanback-launchable-activity):\s+name='([^']+)'/gmu)].map((match) => match[1]).filter((value) => Boolean(value))
  );
  const declaredActivity = activities.size === 1 ? [...activities][0] ?? null : null;
  if (!applicationId || !declaredActivity || !validAndroidName(applicationId)) return null;
  const activityName = declaredActivity.startsWith(".") ? `${applicationId}${declaredActivity}` : declaredActivity.includes(".") ? declaredActivity : `${applicationId}.${declaredActivity}`;
  if (!validAndroidName(activityName)) return null;
  return Object.freeze({ applicationId, activityName, component: `${applicationId}/${activityName}` });
}
function decodeBase64Utf8(value) {
  try {
    const binary = globalThis.atob(value);
    const bytes = Uint8Array.from(binary, (character) => character.charCodeAt(0));
    return new TextDecoder("utf-8", { fatal: false }).decode(bytes);
  } catch {
    return null;
  }
}
function validAndroidName(value) {
  return value.length <= 512 && value.split(".").every(
    (part) => part.length > 0 && [...part].every(
      (character, index) => /[A-Za-z_]/u.test(character) || index > 0 && /[0-9$]/u.test(character)
    )
  );
}

// src/plugin.ts
var ANDROID_GRADLE_PLUGIN_ID = ANDROID_GRADLE_PLUGIN_MANIFEST.id;
var ANDROID_GRADLE_PLUGIN = Object.freeze({
  sdkMajor: ANDROID_GRADLE_PLUGIN_MANIFEST.sdkMajor,
  id: ANDROID_GRADLE_PLUGIN_ID,
  version: ANDROID_GRADLE_PLUGIN_MANIFEST.version,
  manifest: ANDROID_GRADLE_PLUGIN_MANIFEST,
  matches: (context) => {
    const evidence = detectAndroidGradlePluginEvidence(context);
    return evidence !== null && isRunnableGradleWorkspace(evidence);
  },
  evidenceKey: (context) => {
    const evidence = detectAndroidGradlePluginEvidence(context);
    const catalog = catalogEvidence(context.evidence);
    return evidence ? JSON.stringify([
      evidence.platform,
      evidence.bounded,
      evidence.catalogTruncated,
      evidence.gradle,
      evidence.android,
      evidence.wrapper,
      evidence.evidence,
      catalog ? fingerprintPaths(catalog.files, catalog.platform) : []
    ]) : "unsupported";
  },
  activate: (context) => {
    const detected = detectAndroidGradlePluginEvidence(context);
    if (!detected || !isRunnableGradleWorkspace(detected)) return;
    const detection = detected;
    const cache = context.taskCache;
    const catalog = catalogEvidence(context.evidence)?.files ?? [];
    const cachePaths = fingerprintPaths(catalog, detection.platform);
    const listeners = /* @__PURE__ */ new Set();
    let disposed = false;
    let revision = 0;
    let selectedRunConfigurationId = null;
    let selectionRevision = 0;
    let selectionRestored = !context.workspaceState;
    let selectionWrites = Promise.resolve();
    let currentFingerprint = null;
    const cacheMissReason = "cache-miss";
    const publish = () => {
      if (disposed) return;
      for (const listener of listeners) listener();
    };
    const metadata = (status, staleReason, restoredTaskCount) => ({
      status,
      ...staleReason ? { staleReason } : {},
      ...restoredTaskCount === void 0 ? {} : { restoredTaskCount }
    });
    let snapshot = {
      status: cache ? "ready" : "unavailable",
      tasks: [],
      ...cache ? { cache: metadata("validating") } : { unavailableReason: detection.catalogTruncated ? "evidence-incomplete" : "discovery-not-supported" }
    };
    const provider = {
      kind: "provider",
      id: "gradle-tasks",
      label: "Gradle",
      settingsFocus: "taskPresentation",
      snapshot: () => snapshot,
      collections: () => [buildAndroidGradleTaskCollection(snapshot)],
      subscribe: (listener) => {
        listeners.add(listener);
        return { dispose: () => listeners.delete(listener) };
      },
      invalidate: (invalidation) => {
        if (!cache || disposed) return;
        const reason = invalidation.recovery === "none" ? intersectsFingerprintPaths(cachePaths, invalidation.paths, detection.platform) ? "watcher-change" : null : "overflow-recovery";
        if (!reason) return;
        revision += 1;
        snapshot = { ...snapshot, cache: metadata("stale", reason), tasks: disableTasks(snapshot.tasks) };
        currentFingerprint = null;
        publish();
        return cache.markDirty("gradle-tasks", reason === "overflow-recovery" ? "watcher-ambiguous" : "workspace-change").then(() => void 0, () => void 0);
      },
      refresh: () => {
        if (disposed) return null;
        const refreshRevision = ++revision;
        const retainedTasks = snapshot.tasks;
        const prepared = buildGradleWrapperRequest(detection);
        if (!prepared.supported) {
          snapshot = { status: "unavailable", tasks: disableTasks(retainedTasks), cache: metadata("stale", "fingerprint-unavailable"), unavailableReason: prepared.reason === "wrapper-missing" ? "discovery-not-supported" : "evidence-incomplete" };
          publish();
          return null;
        }
        const plan = {
          request: prepared.request,
          apply: (result) => {
            if (disposed || revision !== refreshRevision) return;
            if (result.status !== "succeeded") {
              snapshot = { status: "error", tasks: disableTasks(retainedTasks), cache: metadata("stale", "refresh-failed"), error: result.error ?? (result.status === "cancelled" ? "Gradle task discovery was cancelled." : `Gradle task discovery ${result.status}.`) };
              publish();
              return;
            }
            if (result.truncated) {
              snapshot = { status: "error", tasks: disableTasks(retainedTasks), cache: metadata("stale", "refresh-failed"), error: "Gradle task discovery output was truncated." };
              publish();
              return;
            }
            const chunks = [];
            let byteLength = 0;
            for (const output of result.outputs) {
              if (output.stream !== "stdout") continue;
              try {
                const bytes2 = decodeBase64Bytes(output.dataBase64);
                byteLength += bytes2.byteLength;
                if (byteLength > ANDROID_GRADLE_DISCOVERY_LIMITS.maxOutputBytes) {
                  snapshot = { status: "error", tasks: disableTasks(retainedTasks), cache: metadata("stale", "refresh-failed"), error: "Gradle task discovery output exceeded the discovery limit." };
                  publish();
                  return;
                }
                chunks.push(bytes2);
              } catch {
                snapshot = { status: "error", tasks: disableTasks(retainedTasks), cache: metadata("stale", "refresh-failed"), error: "Gradle task discovery output was invalid." };
                publish();
                return;
              }
            }
            const bytes = new Uint8Array(byteLength);
            let offset = 0;
            for (const chunk of chunks) {
              bytes.set(chunk, offset);
              offset += chunk.byteLength;
            }
            const parsed = parseGradleTasksOutput(bytes);
            if (parsed.status !== "ready") {
              snapshot = { ...parsed, tasks: disableTasks(retainedTasks), cache: metadata("stale", "refresh-failed") };
              publish();
              return;
            }
            const discovered = { ...parsed, tasks: withGradleQuickActions(parsed.tasks) };
            snapshot = { ...discovered, ...cache ? { cache: metadata("validating", void 0, discovered.tasks.length) } : {} };
            publish();
            if (cache) void finalizeRefresh(discovered.tasks, refreshRevision);
          }
        };
        snapshot = { status: "loading", tasks: retainedTasks };
        publish();
        return plan;
      },
      run: async (taskId) => {
        if (disposed) return null;
        if (cache) {
          const fingerprint = await cache.computeFingerprint(cachePaths);
          if (disposed) return null;
          if (fingerprint.status !== "ready" || !currentFingerprint || fingerprint.digest !== currentFingerprint.digest) {
            snapshot = { ...snapshot, cache: metadata("stale", "fingerprint-mismatch"), tasks: snapshot.tasks.map((task) => ({ ...task, runnable: false })) };
            currentFingerprint = null;
            publish();
            return null;
          }
        }
        const plan = buildGradleTaskRunPlan(detection, snapshot, taskId);
        if (!plan) return null;
        snapshot = setGradleTaskRunState(snapshot, taskId, "queued");
        const artifactHints = gradleTaskArtifactHints(taskId);
        return {
          request: plan,
          ...artifactHints.length > 0 ? { artifactSearch: { hints: artifactHints } } : {},
          apply: (result) => {
            snapshot = applyGradleTaskResult(snapshot, taskId, result);
            publish();
          }
        };
      }
    };
    const providerDisposable = context.contribute(provider);
    const commandDisposable = context.contribute({
      kind: "command",
      id: "refresh-gradle-tasks",
      providerId: "gradle-tasks",
      title: () => "Gradle",
      detail: () => "Gradle",
      execute: () => void 0
    });
    const devices = createAndroidDeviceProvider(context);
    const deviceDisposable = context.contribute(devices.contribution);
    const runConfigurationDisposable = context.contribute({
      kind: "run-configuration-provider",
      id: ANDROID_RUN_CONFIGURATION_PROVIDER_ID,
      snapshot: () => androidRunConfigurationSnapshot(
        detection.android ? snapshot : { status: "ready", tasks: [] },
        selectedRunConfigurationId
      ),
      subscribe: (listener) => {
        listeners.add(listener);
        return { dispose: () => {
          listeners.delete(listener);
        } };
      },
      select: async (configurationId) => {
        if (configurationId !== null && (!detection.android || !deriveAndroidRunConfigurations(snapshot).some((configuration) => configuration.id === configurationId))) {
          throw new Error(`Android run configuration is unavailable: ${configurationId}`);
        }
        selectedRunConfigurationId = configurationId;
        selectionRevision++;
        publish();
        await persistSelection(configurationId);
      },
      run: async (configurationId, targetId) => {
        if (!detection.android || !targetId) return null;
        const configuration = deriveAndroidRunConfigurations(snapshot).find((candidate) => candidate.id === configurationId);
        if (!configuration) return null;
        const build = await provider.run(configuration.taskId);
        if (!build?.artifactSearch?.hints.length) return null;
        return buildAndroidStagedRunPlan(build, targetId, configuration.variant, (result) => {
          snapshot = setGradleTaskRunState(snapshot, configuration.taskId, result.status);
          publish();
        });
      }
    });
    devices.start();
    const restoreSelectionRevision = selectionRevision;
    void context.workspaceState?.read("selectedRunConfiguration").then((restored) => {
      if (disposed) return;
      if (selectionRevision === restoreSelectionRevision) selectedRunConfigurationId = restored || null;
      selectionRestored = true;
      reconcileSelection();
      publish();
    }, () => {
      if (!disposed) {
        selectionRestored = true;
        reconcileSelection();
        publish();
      }
    });
    if (cache) void restoreFromCache(revision);
    function persistSelection(value) {
      const write = selectionWrites.catch(() => void 0).then(async () => {
        if (!disposed) await context.workspaceState?.write("selectedRunConfiguration", value ?? "");
      });
      selectionWrites = write;
      return write;
    }
    function reconcileSelection() {
      if (!selectionRestored || !detection.android || snapshot.status !== "ready" || snapshot.cache?.status !== "ready") return;
      const selected = androidRunConfigurationSnapshot(snapshot, selectedRunConfigurationId).selectedConfigurationId;
      if (selected === selectedRunConfigurationId) return;
      selectedRunConfigurationId = selected;
      selectionRevision++;
      void persistSelection(selected).catch(() => void 0);
    }
    async function restoreFromCache(restoreRevision) {
      try {
        const read = await cache.read("gradle-tasks");
        if (disposed || revision !== restoreRevision) return;
        const tasks = decodeAndroidGradleCachePayload(read.payloadBase64, ANDROID_GRADLE_PLUGIN_ID, ANDROID_GRADLE_PLUGIN.manifest.version, "gradle-tasks");
        if (!tasks) {
          snapshot = { status: "ready", tasks: [], cache: metadata("stale", read.status === "unavailable" ? "fingerprint-unavailable" : read.status === "miss" ? cacheMissReason : "cache-corrupt") };
          publish();
          return;
        }
        if (!detection.bounded || detection.catalogTruncated) {
          snapshot = { status: "ready", tasks: gradleTasks(tasks), cache: metadata("stale", "fingerprint-unavailable", tasks.length) };
          publish();
          return;
        }
        if (read.status !== "fresh") {
          const staleReason = read.status === "stale" ? read.staleReason === "expired" || read.staleReason === "future-timestamp" ? "cache-expired" : "cache-corrupt" : read.status === "dirty" ? read.dirtyReason === "watcher-ambiguous" ? "overflow-recovery" : read.dirtyReason === "manual" || read.dirtyReason === "unknown" ? cacheMissReason : "watcher-change" : read.status === "unavailable" ? "fingerprint-unavailable" : read.status === "miss" ? cacheMissReason : "cache-corrupt";
          snapshot = { status: "ready", tasks: gradleTasks(tasks), cache: metadata("stale", staleReason, tasks.length) };
          publish();
          return;
        }
        snapshot = { status: "ready", tasks: gradleTasks(tasks), cache: metadata("validating", void 0, tasks.length) };
        publish();
        const fingerprint = await cache.computeFingerprint(cachePaths);
        if (disposed || revision !== restoreRevision) return;
        currentFingerprint = fingerprint.status === "ready" ? fingerprint : null;
        const match = fingerprint.status === "ready" && read.fingerprint?.digest === fingerprint.digest && read.status === "fresh";
        snapshot = { status: "ready", tasks: match ? gradleTasks(tasks).map((task) => ({ ...task, runnable: true })) : gradleTasks(tasks), cache: match ? metadata("ready", void 0, tasks.length) : metadata("stale", fingerprint.status === "ready" ? "fingerprint-mismatch" : "fingerprint-unavailable", tasks.length) };
        if (!match) currentFingerprint = null;
        reconcileSelection();
        publish();
      } catch {
        if (disposed) return;
        snapshot = { status: "ready", tasks: [], cache: metadata("stale", "cache-corrupt") };
        publish();
      }
    }
    async function finalizeRefresh(tasks, refreshRevision) {
      try {
        const fingerprint = await cache.computeFingerprint(cachePaths);
        if (disposed || revision !== refreshRevision) return;
        if (fingerprint.status !== "ready") {
          snapshot = { ...snapshot, cache: metadata("stale", "fingerprint-unavailable") };
          publish();
          return;
        }
        const payload = encodeAndroidGradleCachePayload(tasks, ANDROID_GRADLE_PLUGIN_ID, ANDROID_GRADLE_PLUGIN.manifest.version, "gradle-tasks");
        const stored = await cache.write("gradle-tasks", fingerprint, payload);
        if (disposed || revision !== refreshRevision) return;
        if (stored.status !== "stored") {
          snapshot = { ...snapshot, cache: metadata("stale", "cache-corrupt") };
          publish();
          return;
        }
        currentFingerprint = fingerprint;
        snapshot = { ...snapshot, status: "ready", tasks: gradleTasks(tasks).map((task) => ({ ...task, runnable: true })), cache: metadata("ready", void 0, tasks.length) };
        reconcileSelection();
        publish();
      } catch {
        if (disposed) return;
        snapshot = { ...snapshot, cache: metadata("stale", "cache-corrupt") };
        publish();
      }
    }
    function gradleTasks(tasks) {
      return tasks.map((task) => ({ ...task, projectPath: task.projectPath ?? ":" }));
    }
    function disableTasks(tasks) {
      return gradleTasks(tasks).map((task) => ({ ...task, runnable: false }));
    }
    return {
      dispose: () => {
        disposed = true;
        listeners.clear();
        void providerDisposable.dispose();
        void commandDisposable.dispose();
        devices.dispose();
        void deviceDisposable.dispose();
        void runConfigurationDisposable.dispose();
      }
    };
  }
});
function detectAndroidGradlePluginEvidence(context) {
  const catalog = catalogEvidence(context.evidence);
  if (!catalog) return null;
  return detectAndroidGradleEvidence({
    workspaceRoot: context.identity.root,
    generation: context.identity.generation,
    platform: catalog.platform,
    files: catalog.files,
    catalogTruncated: catalog.truncated
  });
}
function catalogEvidence(evidence) {
  const value = Array.isArray(evidence) ? evidence.find((candidate) => Boolean(candidate && typeof candidate === "object" && candidate.kind === "workspace-catalog"))?.values : evidence && typeof evidence === "object" && evidence.kind === "workspace-catalog" ? evidence : null;
  if (!value) return null;
  const platform = value.platform;
  const truncated = value.truncated;
  const files = value.files;
  if (platform !== "posix" && platform !== "windows" || typeof truncated !== "boolean" || !Array.isArray(files)) return null;
  const paths = files.map((file) => typeof file === "string" ? file : file && typeof file === "object" && typeof file.workspacePath === "string" ? file.workspacePath : null);
  if (paths.some((file) => file === null)) return null;
  return { platform, truncated, files: paths.map((workspacePath) => ({ workspacePath })) };
}

// src/language-model.ts
var ANDROID_LANGUAGE_MODEL_LIMITS = Object.freeze({ modules: 256, paths: 2e4, pathLength: 4096, bytes: 8 * 1024 * 1024 });
function encodedBytes(value) {
  let bytes = 0;
  for (const char of JSON.stringify(value)) {
    const code = char.codePointAt(0);
    bytes += code < 128 ? 1 : code < 2048 ? 2 : code < 65536 ? 3 : 4;
  }
  return bytes;
}
var MODULE = /^:(?:[A-Za-z0-9_.-]+(?::[A-Za-z0-9_.-]+)*)?$/u;
var VARIANT = /^[A-Za-z0-9_][A-Za-z0-9_.-]{0,159}$/u;
function object(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("Invalid AGP model object");
  return value;
}
function selection(value) {
  if (!MODULE.test(value.module) || !VARIANT.test(value.variant)) throw new Error("Invalid Android model selection");
  return Object.freeze({ module: value.module, variant: value.variant });
}
function absolutePath(value) {
  if (typeof value !== "string" || value.length > ANDROID_LANGUAGE_MODEL_LIMITS.pathLength || /[\u0000-\u001f]/u.test(value) || !/^(?:\/|[A-Za-z]:[\\/]|\\\\[^\\]+\\[^\\]+)/u.test(value) || value.split(/[\\/]/u).some((part) => part === "." || part === "..")) throw new Error("Invalid AGP model path");
  return value;
}
function version(value) {
  if (!/^\d+\.\d+(?:\.\d+)?(?:[-.][A-Za-z0-9]+)*$/u.test(value) || value.length > 64) throw new Error("Invalid Android model tool version");
  return value;
}
function normalizeAgpV2LanguageModel(raw, metadata) {
  const path = absolutePath(metadata.buildRoot);
  const root = /^(?:\/|[A-Za-z]:[\\/])$/u.test(path) ? path : path.replace(/[\\/]$/u, "");
  const requested = selection(metadata.selection);
  const record = object(raw);
  const entries = Object.entries(record);
  if (entries.length === 0 || entries.length > ANDROID_LANGUAGE_MODEL_LIMITS.modules) throw new Error("AGP model module bound exceeded");
  let paths = 0;
  let bytes = 0;
  const textBytes = (value) => {
    bytes += encodedBytes(value);
    if (bytes > ANDROID_LANGUAGE_MODEL_LIMITS.bytes) throw new Error("AGP model byte bound exceeded");
  };
  const list = (value) => {
    if (!Array.isArray(value) || paths + value.length > ANDROID_LANGUAGE_MODEL_LIMITS.paths) throw new Error("AGP model path bound exceeded");
    paths += value.length;
    return Object.freeze([...new Set(value.map((item) => {
      const path2 = absolutePath(item);
      textBytes(path2);
      return path2;
    }))]);
  };
  const modules = entries.map(([id, value]) => {
    const item = object(value);
    if (Object.keys(item).some((key) => !["directory", "variant", "sources", "generatedSources", "bootClasspath", "compileClasspath", "sourceAttachments", "projectDependencies", "javaSourceTarget", "unresolvedCount"].includes(key))) throw new Error("Unknown AGP model field");
    if (typeof item.variant !== "string" || item.unresolvedCount !== 0) throw new Error("Incomplete AGP compile dependencies");
    const chosen = selection({ module: id, variant: item.variant });
    const directory = absolutePath(item.directory);
    const normalizedDirectory = directory.replaceAll("\\", "/");
    const normalizedRoot = root.replaceAll("\\", "/").replace(/\/$/u, "");
    if (normalizedDirectory !== normalizedRoot && !normalizedDirectory.startsWith(`${normalizedRoot}/`)) throw new Error("AGP module is outside this build root");
    if (!Array.isArray(item.projectDependencies) || item.projectDependencies.length > ANDROID_LANGUAGE_MODEL_LIMITS.modules) throw new Error("Invalid AGP project dependency");
    const projectDependencies = item.projectDependencies.map((dependency) => {
      if (typeof dependency === "string") return { module: dependency, variant: item.variant };
      const value2 = object(dependency);
      if (typeof value2.module !== "string" || !MODULE.test(value2.module) || typeof value2.variant !== "string" || !VARIANT.test(value2.variant)) throw new Error("Invalid AGP project dependency");
      return { module: value2.module, variant: value2.variant };
    });
    if (item.javaSourceTarget !== void 0 && item.javaSourceTarget !== null && (typeof item.javaSourceTarget !== "string" || item.javaSourceTarget.length > 32)) throw new Error("Invalid Java source target");
    const sourceAttachments = item.sourceAttachments === void 0 ? [] : item.sourceAttachments;
    if (!Array.isArray(sourceAttachments)) throw new Error("Invalid source attachments");
    const attachments = sourceAttachments.map((attachment) => {
      const value2 = object(attachment);
      return { binary: absolutePath(value2.binary), sources: list(value2.sources) };
    });
    const bootClasspath = list(item.bootClasspath);
    if (bootClasspath.length === 0) throw new Error("Android boot classpath is missing");
    return Object.freeze({ ...chosen, directory, sources: list(item.sources), generatedSources: list(item.generatedSources ?? []), bootClasspath, compileClasspath: list(item.compileClasspath), sourceAttachments: Object.freeze(attachments), projectDependencies: Object.freeze(projectDependencies), javaSourceTarget: item.javaSourceTarget === void 0 ? null : item.javaSourceTarget });
  });
  if (!modules.some((module) => module.module === requested.module && module.variant === requested.variant)) throw new Error("AGP result does not match the selected module and variant");
  const ids = new Set(modules.map((module) => module.module));
  if (modules.some((module) => module.projectDependencies.some(({ module: id }) => !ids.has(id)))) throw new Error("AGP dependency module model is missing");
  return Object.freeze({ schemaVersion: 1, origin: "agp-v2", buildRoot: root, gradleVersion: version(metadata.gradleVersion), agpVersion: version(metadata.agpVersion), selection: requested, modules: Object.freeze(modules) });
}
export {
  ANDROID_DEVICE_DISCOVERY_LIMITS,
  ANDROID_GRADLE_COLLECTION_PROVIDER_ID,
  ANDROID_GRADLE_DETECTOR_LIMITS,
  ANDROID_GRADLE_DISCOVERY_LIMITS,
  ANDROID_GRADLE_EXECUTION_FLAGS,
  ANDROID_GRADLE_PLUGIN,
  ANDROID_GRADLE_PLUGIN_ID,
  ANDROID_GRADLE_PLUGIN_MANIFEST,
  ANDROID_GRADLE_QUICK_ACTION_LIMITS,
  ANDROID_GRADLE_TASK_ARGS,
  ANDROID_LANGUAGE_MODEL_LIMITS,
  ANDROID_RUN_CONFIGURATION_PROVIDER_ID,
  ANDROID_RUN_TARGET_PROVIDER_ID,
  androidRunConfigurationSnapshot,
  applyGradleTaskResult,
  buildAndroidGradleTaskCollection,
  buildAndroidStagedRunPlan,
  buildGradleTaskRunPlan,
  buildGradleWrapperRequest,
  createAndroidDeviceProvider,
  deriveAndroidRunConfigurations,
  deriveGradleQuickActions,
  detectAndroidGradleEvidence,
  detectAndroidGradlePluginEvidence,
  gradleTaskArtifactHints,
  normalizeAgpV2LanguageModel,
  parseAgpOutputMetadata,
  parseAndroidDevicesOutput,
  parseAndroidLaunchComponent,
  parseGradleTasksOutput,
  resolveAgpSingleApkArtifact,
  resolveGradleQuickAction,
  runnableGradleSnapshot,
  setGradleTaskRunState
};
